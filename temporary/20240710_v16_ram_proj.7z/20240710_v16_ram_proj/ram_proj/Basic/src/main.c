#include "time_adapter.h"
#include "trace.h"
#include "rtl876x_gdma.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_aon.h"

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "app_task.h"
#include "vector_table.h"
#include "rtl_ppe.h"

void _system_init_(void)
{
    __enable_irq();
    *(uint32_t *)(0x40006024) |= 0xFFFF00;
    btaon_fast_write_safe(0x744, 0x00);
    extern void log_uart_hw_init(void);
    log_uart_hw_init();

    *(uint32_t *)(0x40006024) |= BIT29 | BIT30; //force clock always on  fix uart baudrate
}

void irq_init()
{
//    NVIC_InitTypeDef NVIC_InitStruct;
//    NVIC_InitStruct.NVIC_IRQChannel = IMDC_VECTORn;
//    NVIC_InitStruct.NVIC_IRQChannelPriority = 3;
//    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStruct);
}

#include "module_lcdc.h"
#include "string.h"
#include "rtl876x_aon_reg.h"
#include "debug_port.h"
#include "platform_utils.h"

int main(void)
{
    irq_init();
    __enable_irq();
    _system_init_();
//  init_timer();
//  delay_us(100);
//  Pad_Config(P2_0, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);

//    DBG_DIRECT("Hello");
//    task_init();
//    sw_timer_init();
//    DBG_DIRECT("line %d", __LINE__);
//    rtk_lcd_hal_init();
//    {
//        uint32_t* reg = (uint32_t*)(0x40000218);
//        uint32_t val = *reg;
//        val |= BIT31;
//        *reg = val;
//        DBG_DIRECT("write 0x40000218 as 0x%08x", *reg);
//    }
//    {
//        uint32_t* reg = (uint32_t*)(0x40000238);
//        uint32_t val = *reg;
//        val |= (BIT14 | BIT16);
//        *reg = val;
//        DBG_DIRECT("write 0x40000238 as 0x%08x", *reg);
//    }
//    {
//        uint32_t* reg = (uint32_t*)(0x40005000 + 0x04);
//        *reg = 0x7;
//    }
//    uint16_t reg_val = btaon_fast_read_safe(0x582);
//    reg_val |= (0x0F);
//    btaon_fast_write_safe(0x582, reg_val);


    AON_FAST_REG0X_REG_SECURITY_S1_0_TYPE aon734 = {.d16 = btaon_fast_read_safe(0x734)};
    //DBG_DIRECT("aon 0x734 0x%04x, M6 %d", aon734.d16, aon734.M6_access_S1_0_enable);
    aon734.M6_access_S1_0_enable = 1;
    btaon_fast_write_safe(0x734, aon734.d16);
    aon734.d16 = btaon_fast_read_safe(0x734);
    //DBG_DIRECT("aon734 after write 0x%04x", aon734.d16);
    
    AON_FAST_REG0X_REG_SECURITY_S2_0_TYPE aon736 = {.d16 = btaon_fast_read_safe(0x736)};
    //DBG_DIRECT("aon 0x736 0x%04x, M6 %d", aon736.d16, aon736.M6_access_S2_0_enable);
    aon736.M6_access_S2_0_enable = 1;
    btaon_fast_write_safe(0x736, aon736.d16);
    aon736.d16 = btaon_fast_read_safe(0x736);
    //DBG_DIRECT("aon736 after write 0x%04x", aon736.d16);
    
    AON_FAST_REG0X_REG_SECURITY_S2_1_TYPE aon738 = {.d16 = btaon_fast_read_safe(0x738)};        //TODO: Address 0x20200000 not accessable
    //DBG_DIRECT("aon 0x738 0x%04x, M6 %d", aon738.d16, aon738.M6_access_S2_1_enable);
    aon738.M6_access_S2_1_enable = 1;
    btaon_fast_write_safe(0x736, aon738.d16);
    aon738.d16 = btaon_fast_read_safe(0x736);
    //DBG_DIRECT("aon738 after write 0x%04x", aon738.d16);
    
    SoC_VENDOR->u_01C.BITS_01C.ppe_clk_always_enable = 1;

#if 0    // @Xueyang        Result Layer only, without input layer
    /*clock enable*/
    uint32_t reg_value = *(uint32_t *)(0x40000234UL);
    reg_value |= (BIT27 | BIT26);
    *(uint32_t *)(0x40000234UL) = reg_value;

    /*function enable*/
    reg_value = *(uint32_t *)(0x40000210UL);
    reg_value |= (BIT24);
    *(uint32_t *)(0x40000210UL) = reg_value;
    
    uint8_t result_addr_mem[10 * 10 * 4];
    memset(result_addr_mem, 0xA5, 10 * 10 * 4);
    *(uint32_t*)(0x40005000 + 0x04) = 0x00000001;
    *(uint32_t*)(0x40005000 + 0x80) = 0x00000000;
    *(uint32_t*)(0x40005000 + 0x88) = 0x00000000;
    *(uint32_t*)(0x40005000 + 0x8C) = 0x00090009;
    *(uint32_t*)(0x40005000 + 0x90) = 0x0000070a;
    *(uint32_t*)(0x40005000 + 0x98) = (uint32_t)result_addr_mem;
    *(uint32_t*)(0x40005000 + 0xA0) = 10 * 4 * 8;
    *(uint32_t*)(0x40005000 + 0xA4) = 0x00010001;
    *(uint32_t*)(0x40005000 + 0x00) |= 0x00000001;
    
    DBG_DIRECT("0x%08x = 0x%08x", (0x40005000 + 0x04), *(uint32_t*)(0x40005000 + 0x04));
    DBG_DIRECT("0x%08x = 0x%08x", (0x40005000 + 0x80), *(uint32_t*)(0x40005000 + 0x80));
    DBG_DIRECT("0x%08x = 0x%08x", (0x40005000 + 0x88), *(uint32_t*)(0x40005000 + 0x88));
    DBG_DIRECT("0x%08x = 0x%08x", (0x40005000 + 0x90), *(uint32_t*)(0x40005000 + 0x90));
    DBG_DIRECT("0x%08x = 0x%08x", (0x40005000 + 0x98), *(uint32_t*)(0x40005000 + 0x98));
    DBG_DIRECT("0x%08x = 0x%08x", (0x40005000 + 0xA0), *(uint32_t*)(0x40005000 + 0xA0));
    DBG_DIRECT("0x%08x = 0x%08x", (0x40005000 + 0xA4), *(uint32_t*)(0x40005000 + 0xA4));
    DBG_DIRECT("0x%08x = 0x%08x", (0x40005000 + 0x00), *(uint32_t*)(0x40005000 + 0x00));
    
    bool success = false;
    uint32_t cycles = 2000000;
    while(cycles)
    {
        if(*(uint32_t*)(0x40005000 + 0x00) & BIT0)
        {
            success = false;
        }
        else
        {
            success = true;
            break;
        }
        cycles--;
    };
    if(success)
    {
        DBG_DIRECT("ppe over");
    }
#if 1
    else
    {
        //suspend -- abort
        *(uint32_t*)(0x40005000 + 0x00) |= 0x00000003;
        DBG_DIRECT("read from swd");
        while(*(uint32_t*)(0x40005000 + 0x00) & BIT0);
        *(uint32_t*)(0x40005000 + 0x00) &= ~(BIT0 | BIT1 | BIT2);
    }
#else
    else
    {
        //debug port
        //0x4000_02A8[19:16] = 4'h2,  [7] = 1'h1, [3:0] = 4'h1
        SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_DBG_MODE_SEL = 2;
        SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_TEST_MODE_EN = 1;
        SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_TEST_MODE = 1;
        
//        extern void debug_port_set_pin_bit_map_rom(T_PIN_GROUP pin_group, uint32_t dbg_bitmap);
//        debug_port_set_pin_bit_map_rom(DBG_PIN_GROUP_B, 0xFF);
        #if 1
        uint16_t reg_value = 0;
        reg_value = btaon_fast_read_safe(0x1596);    //P4_1, MUX_DEBUG[0]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x1596, reg_value);
        
        reg_value = btaon_fast_read_safe(0x1598);    //P4_2, MUX_DEBUG[1]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x1598, reg_value);
        
        reg_value = btaon_fast_read_safe(0x159a);    //P4_3, MUX_DEBUG[2]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x159a, reg_value);
        
        reg_value = btaon_fast_read_safe(0x159c);    //P4_4, MUX_DEBUG[3]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x159c, reg_value);
        
        reg_value = btaon_fast_read_safe(0x159e);    //P4_5, MUX_DEBUG[4]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x159e, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15a0);    //P4_6, MUX_DEBUG[5]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15a0, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15a2);    //P4_7, MUX_DEBUG[6]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15a2, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15a6);    //P5_1, MUX_DEBUG[7]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15a6, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15a8);    //P5_2, MUX_DEBUG[8]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15a8, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15aa);    //P5_3, MUX_DEBUG[9]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15aa, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15ac);    //P5_4, MUX_DEBUG[10]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15ac, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15ae);    //P5_5, MUX_DEBUG[11]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15ae, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15b0);    //P5_6, MUX_DEBUG[12]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15b0, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15c2);    //P7_0, MUX_DEBUG[13]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15c2, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15c4);    //P7_1, MUX_DEBUG[14]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15c4, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15c6);    //P7_2, MUX_DEBUG[15]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15c6, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15c8);    //P7_3, MUX_DEBUG[16]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15c8, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15ca);    //P7_4, MUX_DEBUG[17]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15ca, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15cc);    //P7_5, MUX_DEBUG[18]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15cc, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15ce);    //P7_6, MUX_DEBUG[19]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15ce, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15b4);    //P6_0, MUX_DEBUG[20]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15b4, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15b6);    //P6_1, MUX_DEBUG[21]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15b6, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15b8);    //P6_2, MUX_DEBUG[22]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15b8, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15ba);    //P6_3, MUX_DEBUG[23]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15ba, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15bc);    //P6_4, MUX_DEBUG[24]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15bc, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15be);    //P6_5, MUX_DEBUG[25]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15be, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15c0);    //P6_6, MUX_DEBUG[26]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15c0, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15d0);    //P8_0, MUX_DEBUG[27]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15d0, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15d2);    //P8_1, MUX_DEBUG[28]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15d2, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15d4);    //P8_2, MUX_DEBUG[29]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15d4, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15d6);    //P8_3, MUX_DEBUG[30]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15d6, reg_value);
        
        reg_value = btaon_fast_read_safe(0x15d8);    //P8_4, MUX_DEBUG[31]
        reg_value |= BIT4;
        btaon_fast_write_safe(0x15d8, reg_value);
#endif

        for(uint16_t i = 65; i <= 72; i++)
        {
            uint32_t* reg = (uint32_t*)0x4000601c;
            uint32_t reg_val = *reg;
            reg_val &= 0xFFFFF000;
            reg_val |= i;
            *reg = reg_val;
//            uint32_t read = *(uint32_t*)0x4000601c;
//            DBG_DIRECT("ppe debug port %d = 0x%08x", read);
            platform_delay_ms(10);
        }

    }
#endif
#endif
    extern void IMDC_test(void);
    DBG_DIRECT("Hello");
//    IMDC_test();
#if 1   //@Xueyang      Input layer 1 & 2 & Result layer, identity
    PPE_test();
#endif
//    while(1);
//    vTaskStartScheduler();


    while (1)
    {
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
        __NOP();
    }
    return 0;
}


