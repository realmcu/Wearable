#ifndef _PREINCLUDE_H_
#define _PREINCLUDE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "isr_adapter.h"

#ifdef __cplusplus
}
#endif

#endif /* _PREINCLUDE_H_ */
