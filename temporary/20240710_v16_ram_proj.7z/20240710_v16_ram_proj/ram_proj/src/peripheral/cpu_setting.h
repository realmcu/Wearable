#ifndef CPU_SETTING_H
#define CPU_SETTING_H

/*============================================================================*
 *                               Header Files
*============================================================================*/

#include "cm33_setting.h"

#endif //#define CPU_SETTING_H