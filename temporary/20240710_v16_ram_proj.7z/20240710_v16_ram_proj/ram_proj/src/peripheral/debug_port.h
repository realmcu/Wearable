/**
*********************************************************************************************************
*               Copyright(c) 2024, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* @file      debug_port.h
* @brief
* @details
* @author
* @date      2024-06-28
* @version   v1.0
* *********************************************************************************************************
*/


#ifndef _DEBUG_PORT_H_
#define _DEBUG_PORT_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "rtl876x.h"

typedef enum _t_debug_mode
{
    DIGI_DBG_SYSON,
    DIGI_DBG_BT,
    DIGI_DBG_PROCESSOR_SYS,
    DIGI_DBG_APB_ADC,
    DIGI_DBG_RTC,

    ANA_DBG_AUX_ADC = 0x10,
    ANA_DBG_RF_TRXIQ_AFE_TRMK_ADC,
    ANA_DBG_RF_TRANCERIVER
} T_DEBUG_MODE;


typedef enum _t_debug_pin_group
{
    DBG_PIN_GROUP_A,     //mapping to debug_pin_table_a
    DBG_PIN_GROUP_B,     //mapping to debug_pin_table_b
    DBG_PIN_GROUP_C,     //mapping to debug_pin_table_c
    DBG_PIN_GROUP_ALL_PAD = 0xff,
} T_PIN_GROUP;

/**
  * @brief  Open the debug port mode on specific pins
  * @param  red_table_mask: the pin bit map used in the table debug_pin_table_red.
  * @param  black_table_mask: the pin bit map used in the table debug_pin_table_black.
  * @param  debug_mode: debug mode select from T_DEBUG_MODE
  * @retval None
  */
extern void (*debug_port_open)(T_DEBUG_MODE debug_mode);

/**
  * @brief  Close the debug mode
  * @retval None
  */
void debug_port_close(void);

/**
  * @brief  set debug mode on specific pins
  * @param  pin_group: the pin group selected.
  *   This parameter can be any combination of the following values:
  *     @arg DBG_PIN_GROUP_A : the digital debug pin bit 0 ~ 31 could be selected as below table.
  *             ADC_0,  ADC_1,  ADC_2,   ADC_3,    P3_2,     P3_3,     P1_0,     P1_1,  //digi_debug_0 ~ 7
  *             P1_2,   P1_3,   P1_4,    P1_5,     MIC1_P,   MIC1_N,   P2_0,     P2_1,  //digi_debug_8 ~ 15
  *             P2_2,   P2_3,   P2_4,    P2_5,     P2_6,     P2_7,     P3_4,     P3_5,  //digi_debug_16 ~ 23
  *             MIC2_P, MIC2_N, MICBIAS, DAOUT1_P, DAOUT1_N, DAOUT2_P, DAOUT2_N, P4_0   //digi_debug_24 ~ 31
  *     @arg DBG_PIN_GROUP_B : the digital debug pin bit 0 ~ 31 could be selected as below table.
  *             P4_1,  P4_2,  P4_3,  P4_4,  P4_5,  P4_6,  P4_7,  P5_1,         //digi_debug_0 ~ 7
  *             P5_2,  P5_3,  P5_4,  P5_5,  P5_6,  P7_0,  P7_1,  P7_2,         //digi_debug_8 ~ 15
  *             P7_3,  P7_4,  P7_5,  P7_6,  P6_0,  P6_1,  P6_2,  P6_3,         //digi_debug_16 ~ 23
  *             P6_4,  P6_5,  P6_6,  P8_0,  P8_1,  P8_2,  P8_3,  P8_4          //digi_debug_24 ~ 31
  *     @arg DBG_PIN_GROUP_C : the digital debug pin could be selected as below.
  *             P8_5 for bit0
  *             P5_0 for bit7
  *             P8_6 for bit10
  *             P8_7 for bit11
  *             P10_0 for bit12
  *             P10_1 for bit13
  *             P9_6 for bit30
  *    ATTENTION!!
  *          1. VAUX2 is disabled by default and VDDIO2 is connected on EVB. will need to enable VAUX2
  *             when using the following pins:  P7_0 ~ P7_6, P8_0 ~ P8_5
  *          2. AVCC_DRV is only active when dsp on by default. will need to enable AVCC_DRV
  *             when using hybrid pad
  * @retval None
  */
extern void (*debug_port_set_pin_bit_map)(T_PIN_GROUP pin_group, uint32_t dbg_bitmap);


#ifdef __cplusplus
}
#endif

#endif /* _DEBUG_PORT_H_ */

