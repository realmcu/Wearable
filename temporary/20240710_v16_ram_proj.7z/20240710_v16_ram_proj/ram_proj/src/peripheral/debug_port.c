/**
*********************************************************************************************************
*               Copyright(c) 2024, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
**/

#include "debug_port.h"
#include "rtl876x_pinmux.h"
#include "trace.h"
#include "rtl876x_aon_reg.h"
#include "indirect_access.h"
#include "pcc_reg.h"
#include "pin_def.h"

#define PIN_INVAL       (0xff)

const uint8_t debug_pin_table_a[32] =
{
    ADC_0, ADC_1, ADC_2,   ADC_3,  P3_2,   P3_3,   P1_0,   P1_1,  //digi_debug_0 ~ 7
    P1_2,  P1_3,  P1_4,    P1_5,   MIC1_P,   MIC1_N,   P2_0,   P2_1,  //digi_debug_8 ~ 15
    P2_2,  P2_3,  P2_4,    P2_5,   P2_6,   P2_7,   P3_4,   P3_5,  //digi_debug_16 ~ 23
    MIC2_P, MIC2_N, MICBIAS, DAOUT1_P, DAOUT1_N, DAOUT2_P, DAOUT2_N, P4_0   //digi_debug_24 ~ 31
};

const uint8_t debug_pin_table_b[32] =
{
    P4_1,  P4_2,  P4_3,  P4_4,  P4_5,  P4_6,  P4_7,  P5_1,         //digi_debug_0 ~ 7
    P5_2,  P5_3,  P5_4,  P5_5,  P5_6,  P7_0,  P7_1,  P7_2,         //digi_debug_8 ~ 15
    P7_3,  P7_4,  P7_5,  P7_6,  P6_0,  P6_1,  P6_2,  P6_3,         //digi_debug_16 ~ 23
    P6_4,  P6_5,  P6_6,  P8_0,  P8_1,  P8_2,  P8_3,  P8_4          //digi_debug_24 ~ 31
};

const uint8_t debug_pin_table_c[32] =
{
    P8_5,       PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  P5_0,       PIN_INVAL,   //digi_debug_0 ~ 7
    PIN_INVAL,  PIN_INVAL,  P8_6,  P8_7,  P10_0,  P10_1,       PIN_INVAL,  PIN_INVAL,   //digi_debug_8 ~ 15
    PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,   //digi_debug_16 ~ 23
    PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  PIN_INVAL,  P9_6,  PIN_INVAL,   //digi_debug_24 ~ 31
};

bool debug_port_check_hybrid_pad(uint8_t pin_index, uint8_t dbg_port_index)
{
    if ((pin_index < MIC1_P) | (pin_index > DAOUT1_N))
    {
        return false;
    }

    Pad_AnalogMode(pin_index, PAD_DIGITAL_MODE);
    return true;
}

void debug_port_set_pin_table(uint8_t *dbg_pin_table, uint32_t dbg_bitmap)
{
    if (dbg_bitmap)
    {
        for (uint8_t i = 0; i < 32; i++)
        {
            if ((dbg_bitmap & BIT(i)) && (dbg_pin_table[i] != PIN_INVAL))
            {
                Pad_Config(dbg_pin_table[i], PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE,
                           PAD_OUT_LOW);
                Pinmux_Config(dbg_pin_table[i], DIGI_DEBUG);

//                debug_port_check_hybrid_pad(dbg_pin_table[i], i);
            }
        }
    }
}

void debug_port_set_all_pad(bool is_set)
{
    SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_TEST_MODE_EN = is_set;
}

void debug_port_set_pin_bit_map_rom(T_PIN_GROUP pin_group, uint32_t dbg_bitmap)
{
    switch (pin_group)
    {
    case DBG_PIN_GROUP_A:
        debug_port_set_pin_table((uint8_t *)debug_pin_table_a, dbg_bitmap);
        break;
    case DBG_PIN_GROUP_B:
        debug_port_set_pin_table((uint8_t *)debug_pin_table_b, dbg_bitmap);
        break;
    case DBG_PIN_GROUP_C:
        debug_port_set_pin_table((uint8_t *)debug_pin_table_c, dbg_bitmap);
        break;
    case DBG_PIN_GROUP_ALL_PAD:
        debug_port_set_all_pad(true);
        break;
    default:
        break;
    }
}

void debug_port_open_rom(T_DEBUG_MODE debug_mode)
{
    if (debug_mode < ANA_DBG_AUX_ADC)
    {
        SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_DBG_MODE_SEL = debug_mode;
        SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_TEST_MODE = 0x01;
    }
    else if (debug_mode <= ANA_DBG_RF_TRANCERIVER)
    {
        SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_DBG_MODE_SEL = 0;
        SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_TEST_MODE = debug_mode - ANA_DBG_AUX_ADC + 0x03;
    }
    else
    {
        return;
    }

    SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_DIG_SMUX_EN = 1;

}

void debug_port_close(void)
{
    SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_DIG_SMUX_EN = 0;
    SYSBLKCTRL->u_2A8.BITS_2A8.PMUX_TEST_MODE = 0;
}
