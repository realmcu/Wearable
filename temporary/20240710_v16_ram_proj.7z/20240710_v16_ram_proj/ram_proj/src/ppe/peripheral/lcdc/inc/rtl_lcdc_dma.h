/**
*********************************************************************************************************
*               Copyright(c) 2023, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_lcdc_dma.h
* \brief    The header file of the peripheral GDMA driver.
* \details  This file provides all GDMA firmware functions.
* \author   HOWIE
* \date     2023-10-17
* \version  v1.0
* *********************************************************************************************************
*/

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef RTL_LCDC_DMA_H
#define RTL_LCDC_DMA_H

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                        Header Files
 *============================================================================*/
#include "rtl876x.h"
#if defined CONFIG_SOC_SERIES_RTL87X2G
#include "lcdc/src/rtl87x2g/rtl_lcdc_dma_reg.h"
#endif
#if 1
#include "rtl_lcdc_dma_reg.h"
#endif

/** \defgroup 87X2G_LCDC        LCDC
  * \brief
  * \{
  */

/** \defgroup LCDC_DMA          LCDC_DMA
  * \brief
  * \{
  */

/*============================================================================*
 *                         Constants
 *============================================================================*/
/** \defgroup LCDC_DMA_Exported_Constants LCDC_DMA Exported Constants
  * \brief
  * \{
  */

/**
 * \brief       GDMA Data Transfer Direction
 *
 * \ingroup     LCDC_DMA_Exported_Constants
 */
typedef enum
{
    LCDC_DMA_DIR_PeripheralToMemory = 0x4,
    LCDC_DMA_DIR_PeripheralToPeripheral = 0x6,
} LCDC_DMA_DIRECTION_T;

#define IS_LCDC_DMA_DIR(DIR)  ((DIR) == LCDC_DMA_DIR_PeripheralToMemory) || \
    ((DIR) == LCDC_DMA_DIR_PeripheralToPeripheral))

/**
 * \brief       GDMA Source Incremented Mode
 *
 * \ingroup     LCDC_DMA_Exported_Constants
 */
typedef enum
{
    LCDC_DMA_SourceInc_Inc = 0x0,
    LCDC_DMA_SourceInc_Dec = 0x1,
    LCDC_DMA_SourceInc_Fix = 0x2,
} LCDC_DMA_SRC_INC_T;

#define IS_LCDC_DMA_SourceInc(STATE) (((STATE) == LCDC_DMA_SourceInc_Inc) || \
                                      ((STATE) == LCDC_DMA_SourceInc_Dec) || \
                                      ((STATE) == LCDC_DMA_SourceInc_Fix))

/**
 * \brief       GDMA Destination Incremented Mode
 *
 * \ingroup     LCDC_DMA_Exported_Constants
 */
typedef enum
{
    LCDC_DMA_DestinationInc_Inc = 0x0,
    LCDC_DMA_DestinationInc_Dec = 0x1,
    LCDC_DMA_DestinationInc_Fix = 0x2,
} LCDC_DMA_DEST_INC_T;

#define IS_LCDC_GDMA_DestinationInc(STATE) (((STATE) == LCDC_DMA_DestinationInc_Inc) || \
                                            ((STATE) == LCDC_DMA_DestinationInc_Inc) || \
                                            ((STATE) == LCDC_DMA_DestinationInc_Inc))

/**
 * \brief       GDMA Data Size
 *
 * \ingroup     LCDC_DMA_Exported_Constants
 */
typedef enum
{
    LCDC_DMA_DataSize_Byte     = 0x0,
    LCDC_DMA_DataSize_HalfWord = 0x1,
    LCDC_DMA_DataSize_Word     = 0x2,
} LCDC_DMA_DATASIZE_T;

#define IS_LCDC_GDMA_DATA_SIZE(SIZE) (((SIZE) == LCDC_DMA_DataSize_Byte) || \
                                      ((SIZE) == LCDC_DMA_DataSize_HalfWord) || \
                                      ((SIZE) == LCDC_DMA_DataSize_Word))

/**
 * \brief       GDMA Msize
 *
 * \ingroup     LCDC_DMA_Exported_Constants
 */
typedef enum
{
    LCDC_DMA_Msize_1   = 0x0,
    LCDC_DMA_Msize_4   = 0x1,
    LCDC_DMA_Msize_8   = 0x2,
    LCDC_DMA_Msize_16  = 0x3,
    LCDC_DMA_Msize_32  = 0x4,
    LCDC_DMA_Msize_64  = 0x5,
    LCDC_DMA_Msize_128 = 0x6,
    LCDC_DMA_Msize_256 = 0x7,
} LCDC_DMA_MSIZE_T;

/**
 * \defgroup    LCDC_DMA_SELECTED LCDC_DMA SELECTED
 * \{
 * \ingroup     LCDC_DMA_Exported_Constants
 */
#define LCDC_DMA_AUTO_RELOAD_SELECTED_BIT        (BIT30 | BIT31)
#define LCDC_DMA_LLP_SELECTED_BIT                (BIT27 | BIT28)

/** End of LCDC_DMA_SELECTED
  * \}
  */

/** End of LCDC_DMA_Exported_Constants
  * \}
  */

/*============================================================================*
 *                         Types
 *============================================================================*/
/** \defgroup LCDC_DMA_Exported_Types LCDC_DMA Exported Types
  * \brief
  * \{
  */

/**
 * \brief       LCDC_DMA init structure definition.
 *
 * \ingroup     LCDC_DMA_Exported_Types
 */
typedef struct
{
    uint8_t  LCDC_DMA_ChannelNum;               /*!< Specifies channel number for GDMA. */
    LCDC_DMA_DIRECTION_T  LCDC_DMA_DIR;              /*!< Specifies transfer direction. */
    uint32_t LCDC_DMA_BufferSize;               /*!< Specifies the buffer size(<=65535).
                                                 The data unit is equal to the configuration set in DMA_PeripheralDataSize
                                                 or DMA_MemoryDataSize members depending in the transfer direction. */
    LCDC_DMA_SRC_INC_T LCDC_DMA_SourceInc;          /*!< Specifies whether the source address
                                                 register is incremented or not. */
    LCDC_DMA_DEST_INC_T LCDC_DMA_DestinationInc;    /*!< Specifies whether the destination address
                                                 register is incremented or not.*/
    LCDC_DMA_DATASIZE_T LCDC_DMA_SourceDataSize;    /*!< Specifies the source data width. */
    LCDC_DMA_DATASIZE_T LCDC_DMA_DestinationDataSize; /*!< Specifies the destination data width. */
    LCDC_DMA_MSIZE_T LCDC_DMA_SourceMsize;          /*!< Specifies items number to be transferred. */
    LCDC_DMA_MSIZE_T LCDC_DMA_DestinationMsize;     /*!< Specifies items number to be transferred. */
    uint32_t LCDC_DMA_SourceAddr;               /*!< Specifies the source base address for GDMA Channelx. */
    uint32_t LCDC_DMA_DestinationAddr;          /*!< Specifies the destination base address for GDMA Channelx. */
    uint32_t LCDC_DMA_ChannelPriority;          /*!< Specifies the software priority for the GDMA Channelx.
                                                 This parameter can be a value of 0~7 for GDMA1 and 0~15 for GDMA2. */
    uint32_t LCDC_DMA_Multi_Block_Mode;         /*!< Specifies the multi block transfer mode.
                                                 This parameter can be a value of \ref GDMA_Multiblock_Mode. */
    uint32_t LCDC_DMA_Multi_Block_Struct;       /*!< Pointer to the first struct of LLI. */
    uint8_t  LCDC_DMA_Multi_Block_En;           /*!< Enable or disable multi-block function. */
    uint8_t  LCDC_DMA_SourceHandshake;          /*!< Specifies the handshake index in source.
                                                 This parameter can be a value of \ref GDMA_Handshake_Type. */
    uint8_t  LCDC_DMA_DestHandshake;            /*!< Specifies the handshake index in Destination.
                                                 This parameter can be a value of \ref GDMA_Handshake_Type. */
    uint8_t  LCDC_DMA_Gather_En;                /*!< Enable or disable Gather function. NOTE:4 bytes ALIGN.*/
    uint32_t LCDC_DMA_GatherCount;              /*!< Specifies the GatherCount.NOTE:4 bytes ALIGN.*/
    uint32_t LCDC_DMA_GatherInterval;           /*!< Specifies the GatherInterval. */
    uint8_t  LCDC_DMA_Scatter_En;               /*!< Enable or disable Scatter function. */
    uint32_t LCDC_DMA_ScatterCount;             /*!< Specifies the ScatterCount. */
    uint32_t LCDC_DMA_ScatterInterval;          /*!< Specifies the ScatterInterval. */
    uint32_t LCDC_DMA_GatherCircularStreamingNum;  /*!< Specifies the GatherCircularStreamingNum. */
    uint32_t LCDC_DMA_ScatterCircularStreamingNum; /*!< Specifies the ScatterCircularStreamingNum. */
    uint8_t  LCDC_DMA_Secure_En;                /*!< Enable or disable Secure function. */
} LCDC_DMA_InitTypeDef;

/** End of LCDC_DMA_Exported_Types
  * \}
  */

/*============================================================================*
 *                         Functions
 *============================================================================*/
/** \defgroup LCDC_DMA_Exported_Functions LCDC_DMA Exported Functions
  * \brief
  * \{
  */
void LCDC_DMA_Init(LCDC_DMA_ChannelTypeDef *LCDC_DMA_Channelx,
                   LCDC_DMA_InitTypeDef *LCDC_DMA_InitStruct);

void LCDC_DMA_StructInit(LCDC_DMA_InitTypeDef *LCDC_DMA_InitStruct);

void LCDC_DMAChannelCmd(uint8_t LCDC_DMA_Channel_Num, FunctionalState NewState);

/** End of LCDC_DMA_Exported_Functions
  * \}
  */

/** End of LCDC_DMA
  * \}
  */

/** End of LCDC
  * \}
  */

#ifdef __cplusplus
}
#endif

#endif /* RTL_LCDC_DMA_H */


/******************* (C) COPYRIGHT 2023 Realtek Semiconductor Corporation *****END OF FILE****/

