/**
*********************************************************************************************************
*               Copyright(c) 2023, Realtek Semiconductor Corporation. All rights reserved.
**********************************************************************************************************
* \file     rtl_dbic.h
* \brief    The header file of the peripheral DBIB driver
* \details
* \author   boris yue
* \date     2023-10-17
* \version  v1.0
*********************************************************************************************************
*/

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef RTL_DBIC_H
#define RTL_DBIC_H

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                        Header Files
 *============================================================================*/
#include "rtl_lcdc.h"
#if defined CONFIG_SOC_SERIES_RTL87X2G
#include "lcdc/src/rtl87x2g/rtl_lcdc_dbic_reg.h"
#endif
#if 1
#include "rtl_lcdc_dbic_reg.h"
#endif

/** \defgroup 87X2G_LCDC        LCDC
  * \brief
  * \{
  */

/** \defgroup DBIC              DBIC
  * \brief
  * \{
  */

/*============================================================================*
 *                         Constants
 *============================================================================*/
/** \defgroup DBIC_Exported_Constants DBIC Exported Constants
  * \brief
  * \{
  */

/**
 * \defgroup    DBIC_BIT DBIC BIT
 * \{
 * \ingroup     DBIC_Exported_Constants
 */
#define BIT_CK_MTIMES(x)        (((x) & 0x0000001F) << 23)
#define BIT_FAST_RD(x)          (((x) & 0x00000001) << 22)
#define BIT_CMD_CH(x)           (((x) & 0x00000003) << 20)
#define BIT_DATA_CH(x)          (((x) & 0x00000003) << 18)
#define BIT_ADDR_CH(x)          (((x) & 0x00000003) << 16)
#define BIT_TMOD(x)             (((x) & 0x00000003) << 8)

/** End of DBIC_BIT
  * \}
  */

/**
 * \defgroup    DBIC_Mode DBIC Mode
 * \{
 * \ingroup     DBIC_Exported_Constants
 */
#define DBIC_AUTO_MODE              ((uint32_t)0x0)
#define DBIC_USER_MODE              ((uint32_t)0x1)
#define IS_DBIC_MODE(mode)          ((mode == DBIC_AUTO_MODE) || (mode == DBIC_USER_MODE))

/** End of DBIC_Mode
  * \}
  */

/**
 * \defgroup    DBIC_CMD_CH DBIC CMD CH
 * \{
 * \ingroup     DBIC_Exported_Constants
 */
#define DBIC_CMD_CH_SINGLE          ((uint32_t)0x0)
#define DBIC_CMD_CH_DUAL            ((uint32_t)0x1)
#define DBIC_CMD_CH_QUAD            ((uint32_t)0x2)
#define DBIC_CMD_CH_OCTAL           ((uint32_t)0x3)
#define IS_DBIC_CMD_CH_NUM(num)     ((num == DBIC_CMD_CH_SINGLE) || (num == DBIC_CMD_CH_DUAL) ||\
                                     (num == DBIC_CMD_CH_QUAD) || (num == DBIC_CMD_CH_OCTAL))

/** End of DBIC_CMD_CH
  * \}
  */

/**
 * \defgroup    DBIC_DATA_CH DBIC DATA CH
 * \{
 * \ingroup     DBIC_Exported_Constants
 */
#define DBIC_DATA_CH_SINGLE         ((uint32_t)0x0)
#define DBIC_DATA_CH_DUAL           ((uint32_t)0x1)
#define DBIC_DATA_CH_QUAD           ((uint32_t)0x2)
#define DBIC_DATA_CH_OCTAL          ((uint32_t)0x3)
#define IS_DBIC_DATA_CH_NUM(num)    ((num == DBIC_DATA_CH_SINGLE) || (num == DBIC_DATA_CH_DUAL) ||\
                                     (num == DBIC_DATA_CH_QUAD) || (num == DBIC_DATA_CH_OCTAL))

/** End of DBIC_DATA_CH
  * \}
  */

/**
 * \defgroup    DBIC_ADDR_CH DBIC ADDR CH
 * \{
 * \ingroup     DBIC_Exported_Constants
 */
#define DBIC_ADDR_CH_SINGLE         ((uint32_t)0x0)
#define DBIC_ADDR_CH_DUAL           ((uint32_t)0x1)
#define DBIC_ADDR_CH_QUAD           ((uint32_t)0x2)
#define DBIC_ADDR_CH_OCTAL          ((uint32_t)0x3)
#define IS_DBIC_DATA_CH_NUM(num)    ((num == DBIC_DATA_CH_SINGLE) || (num == DBIC_DATA_CH_DUAL) ||\
                                     (num == DBIC_DATA_CH_QUAD) || (num == DBIC_DATA_CH_OCTAL))

/** End of DBIC_ADDR_CH
  * \}
  */

/**
 * \defgroup    DBIC_TMODE DBIC TMODE
 * \{
 * \ingroup     DBIC_Exported_Constants
 */
#define DBIC_TMODE_TX               ((uint32_t)0x0)
#define DBIC_TMODE_RX               ((uint32_t)0x3)
#define IS_DBIC_DIR(dir)            ((dir == DBIC_TMODE_TX) || (dir == DBIC_TMODE_RX))

/** End of DBIC_TMODE
  * \}
  */

/**
 * \defgroup    DBIC_SCPOL DBIC SCPOL
 * \{
 * \ingroup     DBIC_Exported_Constants
 */
#define DBIC_SCPOL_LOW              ((uint32_t)0x0)
#define DBIC_SCPOL_HIGH             ((uint32_t)0x1)
#define IS_DBIC_SCPOL(pol)          ((pol == DBIC_SCPOL_LOW) || (pol == DBIC_SCPOL_HIGH))

/** End of DBIC_SCPOL
  * \}
  */

/**
 * \defgroup    DBIC_SCPH_Edge DBIC SCPH Edge
 * \{
 * \ingroup     DBIC_Exported_Constants
 */
#define DBIC_SCPH_1Edge             ((uint32_t)0x0)
#define DBIC_SCPH_2Edge             ((uint32_t)0x1)
#define IS_DBIC_SCPH(phase)         ((phase == DBIC_SCPH_1Edge) || (phase == DBIC_SCPH_2Edge))

/** End of DBIC_SCPH_Edge
  * \}
  */

/** End of DBIC_Exported_Constants
  * \}
  */

/*============================================================================*
 *                         Types
 *============================================================================*/
/** \defgroup DBIC_Exported_Types DBIC Exported Types
  * \brief
  * \{
  */

typedef enum
{
    DCX_IMDEPENDENT = 0x0,
    DCX_CRTL_1BIT,
    DCX_CRTL_2BIT,
    DCX_CRTL_4BIT,
    DCX_CRTL_8BIT,
    DCX_CRTL_16BIT,
}LCDC_DBIC_DCX_CTRL_BIT;

typedef enum
{
    DCX_CTRL_BIT_ONCE = 0x0,
    DCX_CTRL_BIT_EACH_1BYTE,
    DCX_CTRL_BIT_EACH_2BYTE,
    DCX_CTRL_BIT_EACH_4BYTE,
    DCX_CTRL_BIT_EACH_8BYTE,
    DCX_CTRL_BIT_EACH_16BYTE,
}LCDC_DBIC_DCX_CTRL;

/**
 * \brief       DBIC init structure definition.
 *
 * \ingroup     DBIC_Exported_Types
 */
typedef struct
{
    uint32_t DBIC_SPEED_SEL;               /*!< Specifies the DBIC clock speed. */
    uint32_t DBIC_TxThr;                  /*!< Specifies the TX FIFO threshold value. This value can be from 0 to 16. */
    uint32_t DBIC_RxThr;
    uint32_t SCPOL;
    uint32_t SCPH;
} LCDC_DBICCfgTypeDef;

typedef struct
{
    FunctionalState             cmd_head_en;
    FunctionalState             cmd_tail_en;
    FunctionalState             addr_head_en;
    FunctionalState             addr_tail_en;
    FunctionalState             data_head_en;
    FunctionalState             data_tail_en;
    LCDC_DBIC_DCX_CTRL_BIT      cmd_ctrl_bit;
    LCDC_DBIC_DCX_CTRL          cmd_ctrl;
    LCDC_DBIC_DCX_CTRL_BIT      addr_ctrl_bit;
    LCDC_DBIC_DCX_CTRL          addr_ctrl;
    LCDC_DBIC_DCX_CTRL_BIT      data_ctrl_bit;
    LCDC_DBIC_DCX_CTRL          data_ctrl;
    uint16_t                    cmd_head_value;
    uint16_t                    cmd_tail_value;
    uint16_t                    addr_head_value;
    uint16_t                    addr_tail_value;
    uint16_t                    data_head_value;
    uint16_t                    data_tail_value;
}LCDC_DBIC_DCX_TypeDef;

/** End of DBIC_Exported_Types
  * \}
  */

/*============================================================================*
 *                         Functions
 *============================================================================*/
/** \defgroup DBIC_Exported_Functions DBIC Exported Functions
  * \brief
  * \{
  */

/**
  * \brief  Enable/disable DBIC interface.
  * \param  NewState: state of DBIC
  * \return None
  */
void DBIC_Cmd(FunctionalState NewState);

/**
  * \brief  Initialize DBIC DCX config structure.
  * \param  None
  * \return None
  */
void DBIC_DCXstruct_Init(LCDC_DBIC_DCX_TypeDef* DBIC_DCX_init_struct);

/**
  * \brief  Initialize DBIC with desired configration.
  * \param  None
  * \return None
  */
void DBIC_DCX_Init(LCDC_DBIC_DCX_TypeDef* DBIC_DCX_init_struct);

/**
  * \brief  Switch to user/auto mode.
  * \param  mode: DBIC mode
  * \return None
  */
void DBIC_SwitchMode(uint32_t mode);

/**
  * \brief  Switch TX/RX direction .
  * \param  dir: TX/RX
  * \return None
  */
void DBIC_SwitchDirect(uint32_t dir);

/**
  * \brief  Configure length of CMD.
  * \param  len: command length
  * \return None
  */
void DBIC_CmdLength(uint32_t len);

/**
  * \brief  Configure length of address.
  * \param  len: address length
  * \return None
  */
void DBIC_AddrLength(uint32_t len);

/**
  * \brief  Each bit in the register corresponds to one SPI Flash. In user mode
  *         user program the register to select target flash. .
  * \return None
  */
void DBIC_Select(void);

/**
  * \brief  Configure num of data frames in bytes.
  * \param  len: data length
  * \return None
  */
void DBIC_TX_NDF(uint32_t len);

/**
  * \brief  Initialize DBIC.
  * \param  DBICCfg: configuration structure of DBIC
  * \return None
  */
void DBIC_Init(LCDC_DBICCfgTypeDef *DBICCfg);

/**
  * \brief  Send data through DBIC interface.
  * \param  buf: data to be sent.
  * \param  len:  data length.
  * \return None
  */
void DBIC_SendBuf(uint8_t *buf, uint32_t len);

/** End of DBIC_Exported_Functions
  * \}
  */

/** End of DBIC
  * \}
  */

/** End of LCDC
  * \}
  */

#ifdef __cplusplus
}
#endif

#endif /*RTL_DBIC_H*/

/******************* (C) COPYRIGHT 2023 Realtek Semiconductor Corporation *****END OF FILE****/

