/**
*********************************************************************************************************
*               Copyright(c) 2023, Realtek Semiconductor Corporation. All rights reserved.
*********************************************************************************************************
* \file     rtl_dsi.h
* \brief    This file provides all the eDPI firmware functions.
* \details
* \author   boris yue
* \date     2023-10-17
* \version  v1.0
*********************************************************************************************************
*/

/*============================================================================*
 *               Define to prevent recursive inclusion
 *============================================================================*/
#ifndef RTL_EDPI_H
#define RTL_EDPI_H

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*
 *                        Header Files
 *============================================================================*/
#include "rtl_lcdc.h"
#if defined CONFIG_SOC_SERIES_RTL87X2G
#include "lcdc/src/rtl87x2g/rtl_lcdc_edpi_reg.h"
#endif
#if 1
#include "rtl_lcdc_edpi_reg.h"
#endif

/** \defgroup 87X2G_LCDC        LCDC
  * \brief
  * \{
  */

/** \defgroup EDPI              EDPI
  * \brief
  * \{
  */

/*============================================================================*
 *                         Types
 *============================================================================*/
/** \defgroup EDPI_Exported_Types EDPI Exported Types
  * \brief
  * \{
  */

typedef struct
{
    uint32_t eDPI_ClockDiv;
    uint32_t eDPI_HoriSyncWidth;
    uint32_t eDPI_VeriSyncHeight;
    uint32_t eDPI_AccumulatedHBP;
    uint32_t eDPI_AccumulatedVBP;
    uint32_t eDPI_AccumulatedActiveW;
    uint32_t eDPI_AccumulatedActiveH;
    uint32_t eDPI_TotalWidth;
    uint32_t eDPI_TotalHeight;
    uint32_t eDPI_HoriSyncPolarity;
    uint32_t eDPI_VeriSyncPolarity;
    uint32_t eDPI_DataEnPolarity;
    uint32_t eDPI_LineIntMask;
    uint32_t eDPI_LineIntFlag;
    uint32_t eDPI_LineIntClr;
    uint32_t eDPI_ColorMap;
    uint32_t eDPI_OperateMode;
    uint32_t eDPI_LcdArc;
    uint32_t eDPI_ShutdnPolarity;
    uint32_t eDPI_ColorModePolarity;
    uint32_t eDPI_ShutdnEn;
    uint32_t eDPI_ColorModeEn;
    uint32_t eDPI_UpdateCfgEn;
    uint32_t eDPI_TearReq;
    uint32_t eDPI_Halt;
    uint32_t eDPI_CmdMaxLatency;
    //uint32_t eDPI_LineBufferPixelNum;
    uint32_t eDPI_LineBufferPixelThreshold;
} LCDC_eDPICfgTypeDef;

typedef enum
{
    EDPI_HSYNCS = 0,
    EDPI_VSYNCS,
    EDPI_HDES,
    EDPI_VDES,
} EDPI_SIGNAL_t;

/** End of EDPI_Exported_Types
  * \}
  */

/*============================================================================*
 *                         Constants
 *============================================================================*/
/** \defgroup EDPI_Exported_Constants EDPI Exported Constants
  * \brief
  * \{
  */

/**
 * \defgroup    EDPI_ClockDiv EDPI ClockDiv
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_CLOCKDIV2                             ((uint32_t)0x1)               //temp
#define EDPI_CLOCKDIV3                             ((uint32_t)0x2)
#define EDPI_CLOCKDIV4                             ((uint32_t)0x3)
#define EDPI_CLOCKDIV5                             ((uint32_t)0x4)
#define EDPI_CLOCKDIV6                             ((uint32_t)0x5)
#define EDPI_CLOCKDIV7                             ((uint32_t)0x6)
#define EDPI_CLOCKDIV8                             ((uint32_t)0x7)

/** End of EDPI_ClockDiv
  * \}
  */

#define IS_EDPI_CLOCKDIV(DIV)   (((DIV) == EDPI_CLOCKDIV2) || ((DIV) == EDPI_CLOCKDIV3) || \
                                 ((DIV) == EDPI_CLOCKDIV4) || ((DIV) == EDPI_CLOCKDIV5) || \
                                 ((DIV) == EDPI_CLOCKDIV6) || ((DIV) == EDPI_CLOCKDIV7) || \
                                 ((DIV) == EDPI_CLOCKDIV8))


/**
 * \defgroup    EDPI_HS_POLARITY  EDPI HS POLARITY
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_HSPOL_AL                (0)            /*!< Horizontal Synchronization is active low. */
#define EDPI_HSPOL_AH                (1)            /*!< Horizontal Synchronization is active high. */

/** End of EDPI_HS_POLARITY
  * \}
  */

#define IS_EDPI_HSPOL(POLARITY)   ((POLARITY) == EDPI_HSPOL_AL) || ((POLARITY) == EDPI_HSPOL_AH)

/**
 * \defgroup    EDPI_VS_POLARITY  EDPI VS POLARITY
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_VSPOL_AL                (0)            /*!< Vertical Synchronization is active low. */
#define EDPI_VSPOL_AH                (1)            /*!< Vertical Synchronization is active high. */

/** End of EDPI_VS_POLARITY
  * \}
  */

#define IS_EDPI_VSPOL(POLARITY)   ((POLARITY) == EDPI_VSPOL_AL) || ((POLARITY) == EDPI_VSPOL_AH)

/**
 * \defgroup    EDPI_DE_POLARITY  EDPI DE POLARITY
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_DEPOL_AL                (0)            /*!< Data Enable, is active low. */
#define EDPI_DEPOL_AH                (1)            /*!< Data Enable, is active high. */

/** End of EDPI_DE_POLARITY
  * \}
  */

#define IS_EDPI_DEPOL(POLARITY)   ((POLARITY) == EDPI_DEPOL_AL) || ((POLARITY) == EDPI_DEPOL_AH)

/**
 * \defgroup    EDPI_INT_MASK EDPI INT MASK
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_LIM_UNMASK            (0)              /*!< pixel clock polarity is active low. */
#define EDPI_LIM_MASK              (1)              /*!< pixel clock is active high. */

/** End of EDPI_INT_MASK
  * \}
  */

#define IS_EDPI_LIM(LIM)   ((LIM) == EDPI_LIM_UNMASK) || ((LIM) == EDPI_LIM_MASK)

/**
 * \defgroup    EDPI_COLOR_MAP EDPI COLOR MAP
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_PIXELFORMAT_RGB888            (0)
#define EDPI_PIXELFORMAT_RGB565_1          ((uint32_t)0x1)   /*!<RGB565_3(R[D15:D11]G[D10:D5]B[D4:D0])*/
#define EDPI_PIXELFORMAT_RGB565_2          ((uint32_t)0x2)   /*!<RGB565_2(R[D20:D16]G[D13:D8]B[D4:D0])*/
#define EDPI_PIXELFORMAT_RGB565_3          ((uint32_t)0x3)   /*!<RGB565_1(R[D21:D17]G[D13:D8]B[D5:D1])*/

/** End of EDPI_COLOR_MAP
  * \}
  */

#define IS_EDPI_PIXELFORMAT(FORMAT)   (((FORMAT) == EDPI_PIXELFORMAT_RGB888) || ((FORMAT) == EDPI_PIXELFORMAT_RGB565_1) || \
                                       ((FORMAT) == EDPI_PIXELFORMAT_RGB565_2) || ((FORMAT) == EDPI_PIXELFORMAT_RGB565_3))

/**
 * \defgroup    EDPI_OP_MODE EDPI OP MODE
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_STANDARD_VIDEO_MODE            (0)             /*!< Standard Video mode. */
#define EDPI_ADAPTED_COMMAND_MODE           (1)             /*!< Adapted Command mode. */

/** End of EDPI_OP_MODE
  * \}
  */

#define IS_EDPI_OP_MODE(MDOE)   ((MODE) == EDPI_STANDARD_VIDEO_MODE) || ((MODE) == EDPI_ADAPTED_COMMAND_MODE)

/**
 * \defgroup    EDPI_LCD_ARC EDPI LCD ARC
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_LCD_ARC_TYPE123            (0)             /*!< LCD Display Driver is of Type 1 or 2or3. */
#define EDPI_LCD_ARC_TYPE4              (1)             /*!< LCD Display Driver is of Type 4. */

/** End of EDPI_LCD_ARC
  * \}
  */

#define IS_EDPI_LCD_ARC_TYPE(TYPE)   ((TYPE) == EDPI_LCD_ARC_TYPE123) || ((TYPE) == EDPI_LCD_ARC_TYPE4)

/**
 * \defgroup    EDPI_SD_EN_FCOLOR EDPI SD EN FCOLOR
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_SD_EN_FCOLOR_BLACK            (0)   /*!< this bit defines the color of the 4 frames is black. */
#define EDPI_SD_EN_FCOLOR_WHITE            (1)   /*!< this bit defines the color of the 4 frames is white. */

/** End of EDPI_SD_EN_FCOLOR
  * \}
  */

#define IS_EDPI_SD_EN_FCOLOR(FCOLOR)   ((FCOLOR) == EDPI_SD_EN_FCOLOR_BLACK) || ((FCOLOR) == EDPI_SD_EN_FCOLOR_WHITE)

/**
 * \defgroup    EDPI_SD_DIS_FCOLOR EDPI SD DIS FCOLOR
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_SD_DIS_FCOLOR_BLACK              (0)           /*!< this bit defines the color of the 12 frames is black. */
#define EDPI_SD_DIS_FCOLOR_WHITE              (1)           /*!< this bit defines the color of the 12 frames is white. */

/** End of EDPI_SD_DIS_FCOLOR
  * \}
  */

#define IS_EDPI_SD_DIS_FCOLOR(FCOLOR)   ((FCOLOR) == EDPI_SD_DIS_FCOLOR_BLACK) || ((FCOLOR) == EDPI_SD_DIS_FCOLOR_WHITE)

/**
 * \defgroup    EDPI_SHUTDN_POLARITY  EDPI SHUTDN POLARITY
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_SDPOL_AL                (0)            /*!< ShutDown is active low. */
#define EDPI_SDPOL_AH                (1)            /*!< ShutDown is active high. */

/** End of EDPI_SHUTDN_POLARITY
  * \}
  */

#define IS_EDPI_SDPOL(POLARITY)   ((POLARITY) == EDPI_SDPOL_AL) || ((POLARITY) == EDPI_SDPOL_AH)

/**
 * \defgroup    EDPI_COLORMODE_POLARITY  EDPI COLORMODE POLARITY
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_CLMPOL_AL                (0)               /*!< ColorMode is active low. */
#define EDPI_CLMPOL_AH                (1)               /*!< ColorMode is active high. */

/** End of EDPI_COLORMODE_POLARITY
  * \}
  */

#define IS_EDPI_CLMPOL(POLARITY)   ((POLARITY) == EDPI_CLMPOL_AL) || ((POLARITY) == EDPI_CLMPOL_AH)

/**
 * \defgroup    EDPI_SHUTDOWN_ENABLE  EDPI SHUTDOWN ENABLE
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_SD_DISABLE                (0)            /*!< ShutDown DISABLE. */
#define EDPI_SD_ENABLE                 (1)            /*!< ShutDown ENABLE. */

/** End of EDPI_SHUTDOWN_ENABLE
  * \}
  */

#define IS_EDPI_SD_CMD(CMD)             ((CMD) == EDPI_SD_DISABLE) || ((CMD) == EDPI_SD_ENABLE)

/**
 * \defgroup    EDPI_COLORMODE_ENABLE  EDPI COLORMODE ENABLE
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_CLM_DISABLE                (0)             /*!< ShutDown is active low. */
#define EDPI_CLM_ENABLE                 (1)             /*!< ShutDown is active high. */

/** End of EDPI_COLORMODE_ENABLE
  * \}
  */

#define IS_EDPI_CLM_CMD(CMD)   ((CMD) == EDPI_CLM_DISABLE) || ((CMD) == EDPI_CLM_ENABLE)

/**
 * \defgroup    EDPI_UPDATECFG_ENABLE  EDPI UPDATECFG ENABLE
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_UPEN_DISABLE                (0)            /*!< ShutDown is active low. */
#define EDPI_UPEN_ENABLE                 (1)            /*!< ShutDown is active high. */

/** End of EDPI_UPDATECFG_ENABLE
  * \}
  */

#define IS_EDPI_UPEN_CMD(CMD)   ((CMD) == EDPI_UPEN_DISABLE) || ((CMD) == EDPI_UPEN_ENABLE)

/**
 * \defgroup    EDPI_TEAR_REQ  EDPI TEAR REQ
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_TEARREQ_AL                (0)              /*!< ShutDown is active low. */
#define EDPI_TEARREQ_AH                (1)              /*!< ShutDown is active high. */

/** End of EDPI_TEAR_REQ
  * \}
  */

#define IS_EDPI_TEARREQ_POLARITY(POLARITY)   ((POLARITY) == EDPI_TEARREQ_AL) || ((POLARITY) == EDPI_TEARREQ_AH)

/**
 * \defgroup    EDPI_HALT_POLARITY  EDPI HALT POLARITY
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_HALT_AL                (0)             /*!< ShutDown is active low. */
#define EDPI_HALT_AH                (1)             /*!< ShutDown is active high. */

/** End of EDPI_HALT_POLARITY
  * \}
  */

#define IS_EDPI_HALT_POLARITY(POLARITY)   ((POLARITY) == EDPI_HALT_AL) || ((POLARITY) == EDPI_HALT_AH)

/**
 * \defgroup    EDPI_DE_CONSTANT EDPI DE CONSTANT
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_DE_CONSTANT_NONE                (0x1)   /*!< 0x1 or 0x2: No constant value for DE, it can be drive by display controller*/
#define EDPI_DE_CONSTANT_LOW                 (0x0)      /*!< constant low for DE. */
#define EDPI_DE_CONSTANT_HIGH                (0x3)      /*!< constant high for DE */

/** End of EDPI_DE_CONSTANT
  * \}
  */

#define IS_EDPI_DE_CONSTANT_VALUE(VALUE)   ((VALUE) == EDPI_DE_CONSTANT_NONE) || ((VALUE) == EDPI_DE_CONSTANT_LOW) || ((VALUE) == EDPI_DE_CONSTANT_HIGH)

/**
 * \defgroup    EDPI_VSYNC_CONSTANT EDPI VSYNC CONSTANT
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_VSYNC_CONSTANT_NONE                (0x1)   /*!< 0x1 or 0x2: No constant value for VSYNC, it can be drive by display controller*/
#define EDPI_VSYNC_CONSTANT_LOW                 (0x0)      /*!< constant low for VSYNC. */
#define EDPI_VSYNC_CONSTANT_HIGH                (0x3)      /*!< constant high for VSYNC */

/** End of EDPI_VSYNC_CONSTANT
  * \}
  */

#define IS_EDPI_VSYNC_CONSTANT_VALUE(VALUE)   ((VALUE) == EDPI_VSYNC_CONSTANT_NONE) || ((VALUE) == EDPI_VSYNC_CONSTANT_LOW) || ((VALUE) == EDPI_VSYNC_CONSTANT_HIGH)

/**
 * \defgroup    EDPI_HSYNC_CONSTANT EDPI HSYNC CONSTANT
 * \{
 * \ingroup     EDPI_Exported_Constants
 */
#define EDPI_HSYNC_CONSTANT_NONE                (0x1)   /*!< 0x1 or 0x2: No constant value for HSYNC, it can be drive by display controller*/
#define EDPI_HSYNC_CONSTANT_LOW                 (0x0)      /*!< constant low for HSYNC. */
#define EDPI_HSYNC_CONSTANT_HIGH                (0x3)      /*!< constant high for HSYNC */

/** End of EDPI_HSYNC_CONSTANT
  * \}
  */

#define IS_EDPI_HSYNC_CONSTANT_VALUE(VALUE)   ((VALUE) == EDPI_HSYNC_CONSTANT_NONE) || ((VALUE) == EDPI_HSYNC_CONSTANT_LOW)  || ((VALUE) == EDPI_HSYNC_CONSTANT_HIGH)

/** End of EDPI_Exported_Constants
  * \}
  */

/*============================================================================*
 *                         Functions
 *============================================================================*/
/** \defgroup EDPI_Exported_Functions EDPI Exported Functions
  * \brief
  * \{
  */

void EDPI_MaskLineINTConfig(FunctionalState state);

void LCDC_ClearLineINTPendingBit(void);

uint16_t EDPI_GetLineINTPos(void);

uint16_t EDPI_GetXPos(void);

uint16_t EDPI_GetYPos(void);

void EDPI_OPMODE_CONFIG(uint32_t mode);

void EDPI_Init(LCDC_eDPICfgTypeDef *eDPICfg);

/** End of EDPI_Exported_Functions
  * \}
  */

/** End of EDPI
  * \}
  */

/** End of LCDC
  * \}
  */

#ifdef __cplusplus
}
#endif

#endif /*RTL_EDPI_H*/


/******************* (C) COPYRIGHT 2023 Realtek Semiconductor Corporation *****END OF FILE****/

