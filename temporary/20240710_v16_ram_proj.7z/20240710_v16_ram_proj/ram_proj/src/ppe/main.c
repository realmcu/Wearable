/**
*****************************************************************************************
*     Copyright(c) 2017, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
   * @file      main.c
   * @brief     Source file for BLE peripheral project, mainly used for initialize modules
   * @author    jane
   * @date      2017-06-12
   * @version   v1.0
   **************************************************************************************
   * @attention
   * <h2><center>&copy; COPYRIGHT 2017 Realtek Semiconductor Corporation</center></h2>
   **************************************************************************************
  */

/*============================================================================*
 *                              Header Files
 *============================================================================*/
#include <trace.h>
#include "rtl876x_rcc.h"
#include "lcd_sh8601z_454_lcdc.h"
#include "os_mem.h"
#include "string.h"
#include "rtl_lcdc.h"
#include <fmc_api.h>
#include "clock_manager.h"
#include "fmc_api_ext.h"
#include "pm.h"
#include "wdg.h"
#include "module_lcdc.h"

void clock_management(void)
{
    uint32_t cpu_freq;
    int32_t ret = pm_cpu_freq_set(100, &cpu_freq);
    if (ret != 0)
    {
        DBG_DIRECT("cpu freq config CLK_80MHZ fail ret %x real freq %dMHz", ret, cpu_freq);
    }
    else
    {
        DBG_DIRECT("cpu freq %dMHz ", cpu_freq);
    }
    fmc_flash_nor_clock_switch(FMC_FLASH_NOR_IDX0, CLK_80MHZ);
    APP_PRINT_INFO2("APP COMPILE TIME: [%s - %s]", TRACE_STRING(__DATE__), TRACE_STRING(__TIME__));

#if 0
    /* set flash address size 4byte if flash size larger than 128Mbit */
    if (fmc_flash_set_4_byte_address_mode(FMC_FLASH_NOR_IDX0, true))
    {
        DBG_DIRECT("flash set 4byte addr success");
    }
    else
    {
        DBG_DIRECT("flash set 4byte addr fail");
    }
#endif
    fmc_flash_set_seq_trans(FMC_FLASH_NOR_IDX0, true);
    if (fmc_flash_try_high_speed_mode(FMC_FLASH_NOR_IDX0, FMC_FLASH_NOR_4_BIT_MODE))
    {
        DBG_DIRECT("flash switch 4bit success");
    }
    else
    {
        DBG_DIRECT("flash switch 4bit fail");
    }
    if (fmc_flash_nor_clock_switch(FMC_FLASH_NOR_IDX0, CLK_160MHZ))
    {
        DBG_DIRECT("set flash clock 160M success");
    }
    else
    {
        DBG_DIRECT("set flash clock 160M fail");
    }
    if (fmc_flash_try_high_speed_mode(FMC_FLASH_NOR_IDX0, FMC_FLASH_NOR_4_BIT_MODE))
    {
        DBG_DIRECT("flash switch 4bit success");
    }
    else
    {
        DBG_DIRECT("flash switch 4bit fail");
    }
    SPIC0->TPR0 = 0x100082;
    if (fmc_psram_winbond_opi_init())
    {
        DBG_DIRECT("WB OPI psram init success!");
    }
    else
    {
        DBG_DIRECT("WB OPI psram init fail!");
    }
    extern bool fmc_psram_clock_switch(CLK_FREQ_TYPE clk);
    if (fmc_psram_clock_switch(CLK_160MHZ))
    {
        DBG_DIRECT("WB OPI psram switch to 80MHz success!");
    }
    else
    {
        DBG_DIRECT("WB OPI psram switch to 80MHz fail!");
    }
}

/**
 * @brief    Entry of APP code
 * @return   int (To avoid compile warning)
 */
int main(void)
{
    DBG_DIRECT("common main");
    WDG_Disable();
    clock_management();
    rtk_lcd_hal_init();
    extern void PPE_test(void);
    PPE_test();
    while (1);
}
/** @} */ /* End of group PERIPH_DEMO_MAIN */


