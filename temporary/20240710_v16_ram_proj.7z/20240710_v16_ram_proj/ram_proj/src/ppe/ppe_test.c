#include "module_lcdc.h"
#include "sample_image.h"
#include "string.h"
#include "rtl_PPE.h"
#include "trace.h"

#define USE_SAMPLE  0
#if USE_SAMPLE
//#include "golden128.h"
#include "identity.h"


#include "fg128.h"
#include "bg128.h"


#define RGB565_BG       0xE170
uint32_t CLUT[256] = {0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFFFFFFFF};
//uint8_t I8[128 * 128];
#endif
#if !USE_SAMPLE
//static uint32_t fg[20 * 20] __attribute__((section(".ARM.__at_0x20200000")));
//static uint32_t bg[20 * 20] __attribute__((section(".ARM.__at_0x20201000")));
//static uint32_t sim[20 * 20] __attribute__((section(".ARM.__at_0x20202000")));
uint32_t fg[20 * 20];
uint32_t bg[20 * 20];
uint32_t sim[20 * 20];
void PPE_test(void)
{
//    DBG_DIRECT("line %d", __LINE__);
    
    for(int i = 0; i < 20 * 20; i++)
    {
        fg[i] = 0x80FF00FF;
        bg[i] = 0x8000FF00;
        sim[i] = 0x8000FF00;
    }

    ppe_buffer_t img, target;
    memset(&img, 0, sizeof(ppe_buffer_t));
    memset(&target, 0, sizeof(ppe_buffer_t));
    target.format = PPE_ABGR8888;
    target.address = (uint32_t)bg;
    target.width = 20;
    target.height = 20;
    target.const_color = 0xFFFFFFFF;
    target.win_x_min = 0;
    target.win_x_max = target.width - 1;
    target.win_y_min = 0;
    target.win_y_max = target.height - 1;

    img.format = PPE_ABGR8888;
    img.address = (uint32_t)fg;
    img.width = 20;
    img.height = 20;
    img.high_quality = false;
    img.opacity = 0xFF;
    img.win_x_min = 0;
    img.win_x_max = target.width - 1;
    img.win_y_min = 0;
    img.win_y_max = target.height - 1;
    img.const_color = 0xFFFFFFFF;
    PPE_color_key_enable(&img, false, 0, 0, 0, 0);
    ppe_matrix_t inv_matrix, matrix;
//    PPE_Register_CLUT(CLUT);
    ppe_get_identity(&matrix);
//    ppe_translate(1, 0, &matrix);
//    ppe_rotate(30, &matrix);
//    ppe_scale(2, 0.5, &matrix);
    memcpy(&inv_matrix, &matrix, sizeof(ppe_matrix_t));
    ppe_matrix_inverse(&inv_matrix);
    ppe_rect_t rect = {.x = 0, .y = 0, .w = 20, .h = 20};
    PPE_Blit_Inverse(&target, &img, &matrix, &inv_matrix, &rect, PPE_BLEND_PREMULTIPLY);
    target.address = (uint32_t)sim;
    PPE_Blit_Inverse_Simulate(&target, &img, &matrix, &inv_matrix, &rect, PPE_BLEND_PREMULTIPLY);
    uint32_t* result = (uint32_t*) bg;
    for(int x = 0; x < 20; x++)
    {
        for (int y = 0; y < 20; y++)
        {
            uint16_t offset = x + y * 20;
            if(result[offset] != sim[offset])
            {
                DBG_DIRECT("sim mismatch at %d, %d: %x vs %x (ex)", x, y, result[offset], sim[offset]);
            }
        }
    }
    DBG_DIRECT("Process Over");
}
#else  //@Xueyang, with golden comparison. PPE Simu: PPE_Blit_Inverse_Simulate

static uint8_t sim_buf[128 * 128 * 4] __attribute__((section(".ARM.__at_0x20200000")));
void PPE_test1(void)
{
//    memset(I8, 0, 4 * 128);
//    memset(I8 +4 * 128, 0xFF, 4 * 128);
//    memset(I8 +4 * 128 * 2, 0, 4 * 128);
//    memset(I8 +4 * 128 * 3, 0xFF, 4 * 128);
//    for(int i = 0; i < 4; i++)
//    {
//        memset(I8 + 128 * 8 * i, i * 0x55, 128 * 8);
//    }
    //memset(I8, 0xFF, 32 * 128);
//    uint16_t *framebuffer = (uint16_t *)0x4000000;
//    uint32_t *simubuffer = (uint32_t *)0x4200000;
//    DBG_DIRECT("buffer addr %x", framebuffer);
//    for (int i = 0; i < 454 * 454; i++)
//    {
//        framebuffer[i] = RGB565_BG;
//        simubuffer[i] = RGB565_BG;
//    }
//    rtk_lcd_hal_set_window(0, 0, 454, 454);
//    rtk_lcd_hal_update_framebuffer(framebuffer, 454 * 454);
//    memcpy(simubuffer, bg128, 65536);
    DBG_DIRECT("BB2Plus PPE test start !!\r\n");

    ppe_buffer_t img, target;
    memset(&img, 0, sizeof(ppe_buffer_t));
    memset(&target, 0, sizeof(ppe_buffer_t));
    target.format = PPE_ABGR8888;
    target.address = (uint32_t)bg128;
    target.width = 128;
    target.height = 128;
    target.const_color = 0xFFFF00FF;
    target.win_x_min = 0;
    target.win_x_max = target.width - 1;
    target.win_y_min = 0;
    target.win_y_max = target.height - 1;

    img.format = PPE_ABGR8888;
    img.address = (uint32_t)fg128;
    img.width = 128;
    img.height = 128;
    img.high_quality = true;
    img.opacity = 0xFF;
    img.win_x_min = 0;
    img.win_x_max = target.width - 1;
    img.win_y_min = 0;
    img.win_y_max = target.height - 1;
    img.const_color = 0xFFFFFFFF;
    PPE_color_key_enable(&img, false, 0, 0, 0, 0);
    ppe_matrix_t inv_matrix, matrix;
    PPE_Register_CLUT(CLUT);
    ppe_get_identity(&matrix);
    ppe_point4_t src, dst;
//    src[0].x = 0;
//    src[0].y = 0;
//    src[1].x = 127;
//    src[1].y = 0;
//    src[2].x = 127;
//    src[2].y = 127;
//    src[3].x = 0;
//    src[3].y = 127;

//    dst[0].x = 0;
//    dst[0].y = 127;
//    dst[1].x = 30;
//    dst[1].y = 15;
//    dst[2].x = 90;
//    dst[2].y = 40;
//    dst[3].x = 115;
//    dst[3].y = 115;
//    ppe_get_transform_matrix(src, dst, &matrix);
    memcpy(&inv_matrix, &matrix, sizeof(ppe_matrix_t));
    ppe_matrix_inverse(&inv_matrix);
    ppe_rect_t rect = {.x = 0, .y = 0, .w = target.width, .h = target.height};
    PPE_Blit_Inverse(&target, &img, &matrix, &inv_matrix, &rect, PPE_BLEND_PREMULTIPLY);
    PPE_Finish();
//    target.address = (uint32_t)sim_buf;
//    PPE_Blit_Inverse_Simulate(&target, &img, &matrix, &inv_matrix, &rect, PPE_BLEND_PREMULTIPLY);
//    rtk_lcd_hal_set_window(150, 150, 128, 128);
//    rtk_lcd_hal_update_framebuffer(simubuffer, 128 * 128);
    uint32_t* expect = (uint32_t*) golden128;
    uint32_t* result = (uint32_t*) bg128;
//    uint32_t* sim = (uint32_t*)sim_buf;
    for(int x = 0; x < 128; x++)
    {
        for (int y = 0; y < 128; y++)
        {
            uint16_t offset = x + y * 128;
            if(result[offset] != expect[offset])
            {
                DBG_DIRECT("mismatch at %d, %d: %x vs %x (ex)", x, y, result[offset], expect[offset]);
            }
        }
    }
//    for(int x = 0; x < 128; x++)
//    {
//        for (int y = 0; y < 128; y++)
//        {
//            uint16_t offset = x + y * 128;
//            if(result[offset] != sim[offset])
//            {
//                DBG_DIRECT("mismatch at %d, %d: %x vs %x (ex)", x, y, result[offset], sim[offset]);
//            }
//        }
//    }

    DBG_DIRECT("Process Over");
}
#endif