#ifndef _LCD_SH8601Z_454_LCDC_H_
#define _LCD_SH8601Z_454_LCDC_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "stdint.h"


#define SH8601A_MAX_PARA_COUNT             (300)

#if defined TARGET_RTL8773E
#define TE_VALID                            0
#else
#define TE_VALID                            1
#endif
#define SH8601A_LCD_WIDTH                   454
#define SH8601A_LCD_HEIGHT                  454
#define SH8601A_DRV_PIXEL_BITS              16
#define INPUT_PIXEL_BYTES                   2
#if INPUT_PIXEL_BYTES == 3
#error "LCDC DMA doesn't allow 3 bytes input"
#endif
#define OUTPUT_PIXEL_BYTES                  3

typedef struct _SH8601A_CMD_DESC
{
    uint8_t instruction;
    uint8_t index;
    uint16_t delay;
    uint16_t wordcount;
    uint8_t  payload[SH8601A_MAX_PARA_COUNT];
} SH8601A_CMD_DESC;

uint32_t SH8601A_get_width(void);
uint32_t SH8601A_get_height(void);
uint32_t SH8601A_get_pixel_bits(void);

void SH8601A_Init_Post_OTP(void);
void SH8601A_qspi_power_on(void);
void SH8601A_qspi_power_off(void);
void SH8601A_set_window(uint16_t xStart, uint16_t yStart, uint16_t w, uint16_t h);

#ifdef __cplusplus
}
#endif

#endif /* _LCD_SH8601Z_454_LCDC_H_ */
