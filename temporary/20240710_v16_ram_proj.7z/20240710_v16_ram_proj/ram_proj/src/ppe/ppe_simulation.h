#include "rtl_PPE.h"

void PPE_Simulation(PPE_ResultLayer_Init_Typedef * PPE_ResultLyaer_Init_Struct,\
                                            PPE_InputLayer_Init_Typedef  * PPE_InputLayer_Init_Struct,\
                                            uint32_t PPE_InputLyaer_ID_ALL
                                            );
