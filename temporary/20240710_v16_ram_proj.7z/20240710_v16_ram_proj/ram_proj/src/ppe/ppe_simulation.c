#include "stdint.h"
#include "stdlib.h"
#include "rtl_PPE.h"
#include "trace.h"
#include "math.h"
#include "ppe_simulation.h"

//#define PPE_DBG       DBG_DIRECT
#define PPE_DBG(format, ...)
typedef struct
{
    union
    {
        struct
        {
            uint8_t r;
            uint8_t g;
            uint8_t b;
            uint8_t a;
        } channel;
        uint32_t abgr_full;
    };
}T_ABGR;

uint32_t Convert_Pixel_Format_to_ABGR8888(uint32_t Input_pixel, PPE_InputLayer_Init_Typedef Input_Layer)
{
    uint32_t data_temp = 0;
    
    /*convert RGB565/RGB888/ARGB8888 to ABGR8888*/
    switch (Input_Layer.Pixel_Color_Format)
    {
        case PPE_ARGB8888:
            data_temp =  (Input_pixel & 0xFF000000)                 + \
                                ((Input_pixel & 0x000000FF) << 16)     + \
                                 (Input_pixel & 0x0000FF00)                  + \
                                ((Input_pixel & 0x00FF0000) >> 16) ;
        break;
        
        case PPE_ABGR8888:
            data_temp =  Input_pixel;
        break;
        
        case PPE_XRGB8888:
            data_temp =  0xFF000000 - (Input_pixel & 0xFF000000)                 + \
                                ((Input_pixel & 0x000000FF) << 16)     + \
                                 (Input_pixel & 0x0000FF00)                  + \
                                ((Input_pixel & 0x00FF0000) >> 16) ;
        break;
        
        case PPE_XBGR8888:
            data_temp =  0xFF000000 - (Input_pixel & 0xFF000000) + (Input_pixel & 0xFFFFFF);
        break;
        
        case PPE_BGRA8888:
            data_temp =  ((Input_pixel & 0xFF000000) >> 8)                 + \
                                ((Input_pixel & 0x000000FF) << 24)     + \
                                ((Input_pixel & 0x0000FF00) >> 8)                  + \
                                ((Input_pixel & 0x00FF0000) >> 8) ;
        break;
        
        case PPE_RGBA8888:
            data_temp =  ((Input_pixel & 0xFF000000) >> 24)                 + \
                                ((Input_pixel & 0x000000FF) << 24)     + \
                                ((Input_pixel & 0x0000FF00) << 8)                  + \
                                ((Input_pixel & 0x00FF0000) >> 8) ;
        break;
        
        case PPE_BGRX8888:
            data_temp =  0xFF000000 -((Input_pixel & 0x000000FF) << 24)     + \
                                ((Input_pixel & 0xFF000000) >> 8)                 + \
                                ((Input_pixel & 0x0000FF00) >> 8)                  + \
                                ((Input_pixel & 0x00FF0000) >> 8) ;
        break;
        
        case PPE_RGBX8888:
            data_temp =  0xFF000000 - ((Input_pixel & 0xFF000000) >> 24)                 + \
                                ((Input_pixel & 0x000000FF) << 24)     + \
                                ((Input_pixel & 0x0000FF00) << 8)                  + \
                                ((Input_pixel & 0x00FF0000) >> 8) ;
        break;
        
        case PPE_ARGB4444:
            data_temp =  ((Input_pixel & 0xF000) << 16) + ((Input_pixel & 0xF000) << 12)       + \
                                ((Input_pixel & 0x0F00) >> 4) + ((Input_pixel & 0x0F00) >> 8)  + \
                                ((Input_pixel & 0x00F0) << 12) + ((Input_pixel & 0x00F0) << 8)                  + \
                                ((Input_pixel & 0x000F) << 20) + ((Input_pixel & 0x000F) << 16) ;
        break;
        
        case PPE_ABGR4444:
            data_temp =  ((Input_pixel & 0xF000) << 16) + ((Input_pixel & 0xF000) << 12)       + \
                                ((Input_pixel & 0x0F00) << 12) + ((Input_pixel & 0x0F00) << 8)  + \
                                ((Input_pixel & 0x00F0) << 8) + ((Input_pixel & 0x00F0) << 4)                  + \
                                ((Input_pixel & 0x000F) << 4) + (Input_pixel & 0x000F) ;
        break;
        
        case PPE_XRGB4444:
            data_temp =  0xFF000000 - ((Input_pixel & 0xF000) << 16) + ((Input_pixel & 0xF000) << 12)       + \
                                ((Input_pixel & 0x0F00) >> 4) + ((Input_pixel & 0x0F00) >> 8)  + \
                                ((Input_pixel & 0x00F0) << 12) + ((Input_pixel & 0x00F0) << 8)                  + \
                                ((Input_pixel & 0x000F) << 20) + ((Input_pixel & 0x000F) << 16) ;
        break;
        
        case PPE_XBGR4444:
            data_temp =  0xFF000000 - ((Input_pixel & 0xF000) << 16) + ((Input_pixel & 0xF000) << 12)       + \
                                ((Input_pixel & 0x0F00) << 12) + ((Input_pixel & 0x0F00) << 8)  + \
                                ((Input_pixel & 0x00F0) << 8) + ((Input_pixel & 0x00F0) << 4)                  + \
                                ((Input_pixel & 0x000F) << 4) + (Input_pixel & 0x000F) ;
        break;
        
        case PPE_BGRA4444:
            data_temp =         ((Input_pixel & 0xF000) << 8) + ((Input_pixel & 0xF000) << 4)       + \
                                ((Input_pixel & 0x0F00) << 4) + ((Input_pixel & 0x0F00) << 0)  + \
                                ((Input_pixel & 0x00F0) << 0) + ((Input_pixel & 0x00F0) >> 4)                  + \
                                ((Input_pixel & 0x000F) << 28) + ((Input_pixel & 0x000F) << 24) ;
        break;
        
        case PPE_RGBA4444:
            data_temp =         ((Input_pixel & 0xF000) << 8) + ((Input_pixel & 0xF000) << 4)       + \
                                ((Input_pixel & 0x0F00) << 4) + ((Input_pixel & 0x0F00) << 0)  + \
                                ((Input_pixel & 0x00F0) << 0) + ((Input_pixel & 0x00F0) >> 4)                  + \
                                ((Input_pixel & 0x000F) << 28) + ((Input_pixel & 0x000F) << 24) ;
        break;
        
        case PPE_BGRX4444:
            data_temp =  0xFF000000 - ((Input_pixel & 0xF000) << 8) + ((Input_pixel & 0xF000) << 4)       + \
                                ((Input_pixel & 0x0F00) << 4) + ((Input_pixel & 0x0F00) << 0)  + \
                                ((Input_pixel & 0x00F0) << 0) + ((Input_pixel & 0x00F0) >> 4)                  + \
                                ((Input_pixel & 0x000F) << 28) + ((Input_pixel & 0x000F) << 24) ;
        break;
        
        case PPE_RGBX4444:
            data_temp =  0xFF000000 - ((Input_pixel & 0xF000) << 8) + ((Input_pixel & 0xF000) << 4)       + \
                                ((Input_pixel & 0x0F00) << 4) + ((Input_pixel & 0x0F00) << 0)  + \
                                ((Input_pixel & 0x00F0) << 0) + ((Input_pixel & 0x00F0) >> 4)                  + \
                                ((Input_pixel & 0x000F) << 28) + ((Input_pixel & 0x000F) << 24) ;
        break;
        
        case PPE_ARGB2222:
            data_temp =         (((Input_pixel >> 6) & 0x03) * 85 << 24)       + \
                                (((Input_pixel >> 4) & 0x03) * 85 << 0)  + \
                                (((Input_pixel >> 2) & 0x03) * 85 << 8)                  + \
                                ((Input_pixel & 0x03) * 85 << 16) ;
        break;
        
        case PPE_ABGR2222:
            data_temp =         (((Input_pixel >> 6) & 0x03) * 85 << 24)       + \
                                (((Input_pixel >> 4) & 0x03) * 85 << 16)  + \
                                (((Input_pixel >> 2) & 0x03) * 85 << 8)                  + \
                                ((Input_pixel & 0x03) * 85 << 0) ;
        break;
        
        case PPE_XRGB2222:
            data_temp =  0xFF000000 - (((Input_pixel >> 6) & 0x03) * 85 << 24)       + \
                                (((Input_pixel >> 4) & 0x03) * 85 << 0)  + \
                                (((Input_pixel >> 2) & 0x03) * 85 << 8)                  + \
                                ((Input_pixel & 0x03) * 85 << 16) ;
        break;
        
        case PPE_XBGR2222:
            data_temp =  0xFF000000 - (((Input_pixel >> 6) & 0x03) * 85 << 24)       + \
                                (((Input_pixel >> 4) & 0x03) * 85 << 16)  + \
                                (((Input_pixel >> 2) & 0x03) * 85 << 8)                  + \
                                ((Input_pixel & 0x03) * 85 << 0) ;
        break;
        
        case PPE_BGRA2222:
            data_temp =         (((Input_pixel >> 6) & 0x03) * 85 << 16)       + \
                                (((Input_pixel >> 4) & 0x03) * 85 << 8)  + \
                                (((Input_pixel >> 2) & 0x03) * 85 << 0)                  + \
                                ((Input_pixel & 0x03) * 85 << 24) ;
        break;
        
        case PPE_RGBA2222:
            data_temp =         (((Input_pixel >> 6) & 0x03) * 85 << 0)       + \
                                (((Input_pixel >> 4) & 0x03) * 85 << 8)  + \
                                (((Input_pixel >> 2) & 0x03) * 85 << 16)                  + \
                                ((Input_pixel & 0x03) * 85 << 24) ;
        break;
        
        case PPE_BGRX2222:
            data_temp =  0xFF000000 - (((Input_pixel >> 6) & 0x03) * 85 << 16)       + \
                                (((Input_pixel >> 4) & 0x03) * 85 << 8)  + \
                                (((Input_pixel >> 2) & 0x03) * 85 << 0)                  + \
                                ((Input_pixel & 0x03) * 85 << 24) ;
        break;
        
        case PPE_RGBX2222:
            data_temp =  0xFF000000 - (((Input_pixel >> 6) & 0x03) * 85 << 0)       + \
                                (((Input_pixel >> 4) & 0x03) * 85 << 8)  + \
                                (((Input_pixel >> 2) & 0x03) * 85 << 16)                  + \
                                ((Input_pixel & 0x03) * 85 << 24) ;
        break;
        
        case PPE_ARGB8565:
            data_temp =  ((Input_pixel & 0xFF0000) << 8)                  + \
                                ((((Input_pixel & 0x001F) << 3) + ((Input_pixel & 0x001C) >> 2)) << 16)     + \
                                 (((Input_pixel & 0x07E0) << 5) + ((Input_pixel & 0x0600) >> 1))                    + \
                                ((((Input_pixel & 0xF800) << 8) + ((Input_pixel & 0xE000) << 3)) >> 16);
        break;
        
        case PPE_ABGR8565:
            data_temp =  ((Input_pixel & 0xFF0000) << 8)                  + \
                                ((((Input_pixel & 0x001F) << 3) + ((Input_pixel & 0x001C) >> 2)))     + \
                                 (((Input_pixel & 0x07E0) << 5) + ((Input_pixel & 0x0600) >> 1))                    + \
                                ((((Input_pixel & 0xF800) << 8) + ((Input_pixel & 0xE000) << 3)));
        break;
        
        case PPE_XRGB8565:
            data_temp =  0xFF000000 - ((Input_pixel & 0xFF0000) << 8)                  + \
                                ((((Input_pixel & 0x001F) << 3) + ((Input_pixel & 0x001C) >> 2)) << 16)     + \
                                 (((Input_pixel & 0x07E0) << 5) + ((Input_pixel & 0x0600) >> 1))                    + \
                                ((((Input_pixel & 0xF800) << 8) + ((Input_pixel & 0xE000) << 3)) >> 16);
        break;
        
        case PPE_XBGR8565:
            data_temp =  0xFF000000 - ((Input_pixel & 0xFF0000) << 8)                  + \
                                ((((Input_pixel & 0x001F) << 3) + ((Input_pixel & 0x001C) >> 2)))     + \
                                 (((Input_pixel & 0x07E0) << 5) + ((Input_pixel & 0x0600) >> 1))                    + \
                                ((((Input_pixel & 0xF800) << 8) + ((Input_pixel & 0xE000) << 3)));
        break;
        
        case PPE_BGRA5658:
            data_temp =  ((Input_pixel & 0xFF) << 24)                  + \
                                ((((Input_pixel & 0x001F00) >> 5) + ((Input_pixel & 0x001C00) >> 10)))     + \
                                 (((Input_pixel & 0x07E000) >> 3) + ((Input_pixel & 0x060000) >> 9))                    + \
                                ((((Input_pixel & 0xF80000) << 0) + ((Input_pixel & 0xE00000) >> 5)));
        break;
        
        case PPE_RGBA5658:
            data_temp =  ((Input_pixel & 0xFF) << 24)                  + \
                                ((((Input_pixel & 0x001F00) << 3) + ((Input_pixel & 0x001C00) >> 2)) << 8)     + \
                                ((((Input_pixel & 0x07E000) << 5) + ((Input_pixel & 0x060000) >> 1)) >> 8)                    + \
                                ((((Input_pixel & 0xF80000) << 8) + ((Input_pixel & 0xE00000) << 3)) >> 24);;
        break;
        
        case PPE_BGRX5658:
            data_temp =  0xFF000000 - ((Input_pixel & 0xFF) << 24)                  + \
                                ((((Input_pixel & 0x001F00) >> 5) + ((Input_pixel & 0x001C00) >> 10)))     + \
                                 (((Input_pixel & 0x07E000) >> 3) + ((Input_pixel & 0x060000) >> 9))                    + \
                                ((((Input_pixel & 0xF80000) << 0) + ((Input_pixel & 0xE00000) >> 5)));
        break;
        
        case PPE_RGBX5658:
            data_temp =  0xFF000000 - ((Input_pixel & 0xFF) << 24)                  + \
                                ((((Input_pixel & 0x001F00) << 3) + ((Input_pixel & 0x001C00) >> 2)) << 8)     + \
                                ((((Input_pixel & 0x07E000) << 5) + ((Input_pixel & 0x060000) >> 1)) >> 8)                    + \
                                ((((Input_pixel & 0xF80000) << 8) + ((Input_pixel & 0xE00000) << 3)) >> 24);;
        break;
        
        case PPE_ABGR1555:
            data_temp =  ((Input_pixel & 0x8000) << 9) * 0xFF                  + \
                                 (((Input_pixel & 0x001F) << 3) + ((Input_pixel & 0x001C) >> 2))     + \
                                 (((Input_pixel & 0x03E0) << 6) + ((Input_pixel & 0x0380) << 1))                    + \
                                 (((Input_pixel & 0x7C00) << 9) + ((Input_pixel & 0x7000) << 4));
        break;
        
        case PPE_ARGB1555:
            data_temp =  ((Input_pixel & 0xFF0000) << 8)                  + \
                                 (((Input_pixel & 0x001F) << 19) + ((Input_pixel & 0x001C) << 14))     + \
                                 (((Input_pixel & 0x07E0) << 5) + ((Input_pixel & 0x0600) >> 1))                    + \
                                 (((Input_pixel & 0xF800) >> 8) + ((Input_pixel & 0xE000) >> 13));
        break;
        
        case PPE_XBGR1555:
            data_temp =  0xFF000000 - ((Input_pixel & 0x8000) << 9) * 0xFF                  + \
                                 (((Input_pixel & 0x001F) << 3) + ((Input_pixel & 0x001C) >> 2))     + \
                                 (((Input_pixel & 0x03E0) << 6) + ((Input_pixel & 0x0380) << 1))                    + \
                                 (((Input_pixel & 0x7C00) << 9) + ((Input_pixel & 0x7000) << 4));
        break;
        
        case PPE_XRGB1555:
            data_temp =  0xFF000000 - ((Input_pixel & 0xFF0000) << 8)                  + \
                                 (((Input_pixel & 0x001F) << 19) + ((Input_pixel & 0x001C) << 14))     + \
                                 (((Input_pixel & 0x07E0) << 5) + ((Input_pixel & 0x0600) >> 1))                    + \
                                 (((Input_pixel & 0xF800) >> 8) + ((Input_pixel & 0xE000) >> 13));
        break;
        
        case PPE_BGRA5551:
            data_temp =  ((Input_pixel & 0x0001) << 24) * 0xFF                  + \
                                 (((Input_pixel & 0x003E) << 2) + ((Input_pixel & 0x0038) >> 3))     + \
                                 (((Input_pixel & 0x07C0) << 5) + ((Input_pixel & 0x0700) << 0))                    + \
                                 (((Input_pixel & 0xF800) << 8) + ((Input_pixel & 0xE000) << 3));
        break;
        
        case PPE_RGBA5551:
            data_temp =  ((Input_pixel & 0x0001) << 24) * 0xFF                  + \
                                 (((Input_pixel & 0x003E) << 18) + ((Input_pixel & 0x0038) << 13))     + \
                                 (((Input_pixel & 0x07C0) << 5) + ((Input_pixel & 0x0700) << 0))                    + \
                                 (((Input_pixel & 0xF800) >>8) + ((Input_pixel & 0xE000) >> 13));
        break;
        
        case PPE_BGRX5551:
            data_temp =  0xFF000000 - ((Input_pixel & 0x0001) << 24) * 0xFF                  + \
                                 (((Input_pixel & 0x003E) << 2) + ((Input_pixel & 0x0038) >> 3))     + \
                                 (((Input_pixel & 0x07C0) << 5) + ((Input_pixel & 0x0700) << 0))                    + \
                                 (((Input_pixel & 0xF800) << 8) + ((Input_pixel & 0xE000) << 3));
        break;
        
        case PPE_RGBX5551:
            data_temp =  0xFF000000 - ((Input_pixel & 0x0001) << 24) * 0xFF                  + \
                                 (((Input_pixel & 0x003E) << 18) + ((Input_pixel & 0x0038) << 13))     + \
                                 (((Input_pixel & 0x07C0) << 5) + ((Input_pixel & 0x0700) << 0))                    + \
                                 (((Input_pixel & 0xF800) >>8) + ((Input_pixel & 0xE000) >> 13));
        break;
        
        case PPE_RGB888:
            data_temp =                               (0xFF000000)                 + \
                                ((Input_pixel & 0x000000FF) << 16)     + \
                                 (Input_pixel & 0x0000FF00)                  + \
                                ((Input_pixel & 0x00FF0000) >> 16) ;
                                // extend the RGB888 with A=0xFF,A B G R 
        break;
        
        case PPE_BGR888:
            data_temp =  Input_pixel | 0xFF000000;
        break;
        
        case PPE_RGB565:
            data_temp =         0xFF000000                  + \
                                ((((Input_pixel & 0x001F) << 3) + ((Input_pixel & 0x001C) >> 2)) << 16)     + \
                                 (((Input_pixel & 0x07E0) << 5) + ((Input_pixel & 0x0600) >> 1))                    + \
                                ((((Input_pixel & 0xF800) << 8) + ((Input_pixel & 0xE000) << 3)) >> 16);
                                //extend the  A=0xFF, fill the lsb with msb of each color, A B G R
        break;
        
        case PPE_BGR565:
            data_temp =         0xFF000000                  + \
                                ((((Input_pixel & 0x001F) << 3) + ((Input_pixel & 0x001C) >> 2)))     + \
                                 (((Input_pixel & 0x07E0) << 5) + ((Input_pixel & 0x0600) >> 1))                    + \
                                ((((Input_pixel & 0xF800) << 8) + ((Input_pixel & 0xE000) << 3)));
                                //extend the  A=0xFF, fill the lsb with msb of each color, A B G R
        break;
        
        case PPE_A8:
            data_temp =      (Input_pixel << 24) + 0xFFFFFF;
        break;
        
        case PPE_X8:
            data_temp =      ((0xFF - Input_pixel) << 24) + + 0xFFFFFF;
        break;
        
        case PPE_A4:
            data_temp =      (Input_pixel * 0x11 << 24) + 0xFFFFFF;
        break;
        
        case PPE_X4:
            data_temp =      0xFF000000 - (Input_pixel * 0x11 << 24) + 0xFFFFFF;
        break;
        
        case PPE_A2:
            data_temp =      (Input_pixel * 0x55 << 24) + 0xFFFFFF;
        break;
        
        case PPE_X2:
            data_temp =      0xFF000000 - (Input_pixel * 0x55 << 24) + 0xFFFFFF;
        break;
        
        case PPE_A1:
            data_temp =      (Input_pixel * 0xFF << 24) + 0xFFFFFF;
        break;
        
        case PPE_X1:
            data_temp =      0xFF000000 - (Input_pixel * 0xFF << 24) + 0xFFFFFF;
        break;
        
        case PPE_ABGR8666:
            data_temp =      Input_pixel + (Input_pixel & 0xC00000 >> 6)        +\
                                           (Input_pixel & 0x00C000 >> 6)        +\
                                           (Input_pixel & 0x0000C0 >> 6);
        break;
        
        case PPE_ARGB8666:
            data_temp =      (Input_pixel & 0xFF000000) +\
                                (((Input_pixel & 0x00FF0000) + ((Input_pixel & 0x00C00000) >> 6)) >> 16)  +\
                                (((Input_pixel & 0x0000FF00) + ((Input_pixel & 0x0000C000) >> 6)) >> 0)  +\
                                (((Input_pixel & 0x000000FF) + ((Input_pixel & 0x000000C0) >> 6)) << 16);
        break;
        
        case PPE_XBGR8666:
            data_temp =     0xFF000000 - (Input_pixel & 0xFF000000) + (Input_pixel & 0x00FFFFFF) + \
                                            (Input_pixel & 0xC00000 >> 6)        +\
                                           (Input_pixel & 0x00C000 >> 6)        +\
                                           (Input_pixel & 0x0000C0 >> 6);
        break;
        
        case PPE_XRGB8666:
            data_temp =      0xFF000000 - (Input_pixel & 0xFF000000) +\
                                (((Input_pixel & 0x00FF0000) + ((Input_pixel & 0x00C00000) >> 6)) >> 16)  +\
                                (((Input_pixel & 0x0000FF00) + ((Input_pixel & 0x0000C000) >> 6)) >> 0)  +\
                                (((Input_pixel & 0x000000FF) + ((Input_pixel & 0x000000C0) >> 6)) << 16);
        break;
        
        case PPE_BGRA6668:
            data_temp =         ((Input_pixel & 0x000000FF) << 24) +\
                                (((Input_pixel & 0xFF000000) + ((Input_pixel & 0xC0000000) >> 6)) >> 8)  +\
                                (((Input_pixel & 0x00FF0000) + ((Input_pixel & 0x00C00000) >> 6)) >> 8)  +\
                                (((Input_pixel & 0x000000FF) + ((Input_pixel & 0x0000C000) >> 6)) >> 8);
        break;
        
        case PPE_RGBA6668:
            data_temp =         ((Input_pixel & 0x000000FF) << 24) +\
                                (((Input_pixel & 0xFF000000) + ((Input_pixel & 0xC0000000) >> 6)) >> 24)  +\
                                (((Input_pixel & 0x00FF0000) + ((Input_pixel & 0x00C00000) >> 6)) >> 8)  +\
                                (((Input_pixel & 0x000000FF) + ((Input_pixel & 0x0000C000) >> 6)) << 8);
        break;
        
        case PPE_BGRX6668:
            data_temp =         0xFF000000 - ((Input_pixel & 0x000000FF) << 24) +\
                                (((Input_pixel & 0xFF000000) + ((Input_pixel & 0xC0000000) >> 6)) >> 8)  +\
                                (((Input_pixel & 0x00FF0000) + ((Input_pixel & 0x00C00000) >> 6)) >> 8)  +\
                                (((Input_pixel & 0x000000FF) + ((Input_pixel & 0x0000C000) >> 6)) >> 8);
        break;
        
        case PPE_RGBX6668:
            data_temp =         0xFF000000 - ((Input_pixel & 0x000000FF) << 24) +\
                                (((Input_pixel & 0xFF000000) + ((Input_pixel & 0xC0000000) >> 6)) >> 24)  +\
                                (((Input_pixel & 0x00FF0000) + ((Input_pixel & 0x00C00000) >> 6)) >> 8)  +\
                                (((Input_pixel & 0x000000FF) + ((Input_pixel & 0x0000C000) >> 6)) << 8);
        break;
        
        case PPE_BGR565_S:
            data_temp =         0xFF000000 + \
                                ((Input_pixel & 0xF1) << 16) + ((Input_pixel & 0xE0) << 11)  +\
                                ((Input_pixel & 0x07) << 13) + ((Input_pixel & 0xE000) >> 3) + ((Input_pixel & 0x06) << 7) +\
                                ((Input_pixel & 0x1F00) >> 5) + ((Input_pixel & 0x1C) >> 10);
        break;
        
        case PPE_RGB565_S:
            data_temp =         0xFF000000 + \
                                ((Input_pixel & 0xF1) << 0) + ((Input_pixel & 0xE0) >> 5)  +\
                                ((Input_pixel & 0x07) << 13) + ((Input_pixel & 0xE000) >> 3) + ((Input_pixel & 0x06) << 7) +\
                                ((Input_pixel & 0x1F00) << 11) + ((Input_pixel & 0x1C) << 6);
        break;
        
        case PPE_I8:
        case PPE_I4:
        case PPE_I2:
        case PPE_I1:
            if (Input_Layer.Index_Table == NULL)
            {
                PPE_DBG("Invalid CLUT");
                assert_param("Input_Layer.Index_Table != NULL");
            }
            data_temp =         Input_Layer.Index_Table[Input_pixel];
        break;
        
        default:
            PPE_DBG("No such format");
            assert_param(NULL != NULL);
        break;
    }
    return data_temp;
}


uint32_t blend_2pixel_ABGR8888(uint32_t background_pixel,uint32_t front_ground_pixel, PPE_BLEND_METHOD method)
{
    uint8_t back_A = (background_pixel >> 24) & 0Xff;
    uint8_t back_B = (background_pixel >> 16) & 0Xff;;
    uint8_t back_G = (background_pixel >> 8)  & 0Xff;;
    uint8_t back_R = (background_pixel >> 0)  & 0Xff;;
    
    uint8_t front_A = (front_ground_pixel >> 24) & 0Xff;
    uint8_t front_B = (front_ground_pixel >> 16) & 0Xff;
    uint8_t front_G = (front_ground_pixel >> 8)  & 0Xff;
    uint8_t front_R = (front_ground_pixel >> 0)  & 0Xff;
    
    uint16_t result_A = 0;
    uint16_t result_B = 0;
    uint16_t result_G = 0;
    uint16_t result_R = 0;
    
    switch(method)
    {
        case PPE_BLEND_PREMULTIPLY:
            result_A = ((front_A*front_A + back_A*(255-front_A))/255) & 0xFF;
            result_B = ((front_B*front_A + back_B*(255-front_A))/255) & 0xFF;
            result_G = ((front_G*front_A + back_G*(255-front_A))/255) & 0xFF;
            result_R = ((front_R*front_A + back_R*(255-front_A))/255) & 0xFF;
        break;
        
        case PPE_BLEND_SRC:
            result_A = front_A;
            result_B = front_B;
            result_G = front_G;
            result_R = front_R;
        break;
        
        case PPE_BLEND_SRC_OVER:
        {
            result_A = (0xFF * front_A + (0xFF - front_A) * back_A) / 0xFF;
            result_B = (0xFF * front_B + (0xFF - front_A) * back_B) / 0xFF;
            result_G = (0xFF * front_G + (0xFF - front_A) * back_G) / 0xFF;
            result_R = (0xFF * front_R + (0xFF - front_A) * back_R) / 0xFF;
        }
            break;
        case PPE_BLEND_DST_OVER:
        {
            result_A = (0xFF * back_A + (0xFF - back_A) * front_A) / 0xFF;
            result_B = (0xFF * back_B + (0xFF - back_A) * front_B) / 0xFF;
            result_G = (0xFF * back_G + (0xFF - back_A) * front_G) / 0xFF;
            result_R = (0xFF * back_R + (0xFF - back_A) * front_R) / 0xFF;
        }
            break;
        case PPE_BLEND_SRC_IN:
        {
            result_A = back_A * front_A / 255;
            result_B = back_A * front_B / 255;
            result_G = back_A * front_G / 255;
            result_R = back_A * front_R / 255;
        }
            break;
        case PPE_BLEND_DST_IN:
        {
            result_A = front_A * back_A / 255;
            result_B = front_A * back_B / 255;
            result_G = front_A * back_G / 255;
            result_R = front_A * back_R / 255;
        }
            break;
        case PPE_BLEND_MULTIPLY:
        {
            result_A = (front_A * (0xFF - back_A) + back_A * (0xFF - front_A) + front_A * back_A) / 255;
            result_B = (front_B * (0xFF - back_A) + back_B * (0xFF - front_A) + front_B * back_B) / 255;
            result_G = (front_G * (0xFF - back_A) + back_G * (0xFF - front_A) + front_G * back_G) / 255;
            result_R = (front_R * (0xFF - back_A) + back_R * (0xFF - front_A) + front_R * back_R) / 255;
        }
            break;
        case PPE_BLEND_SCREEN:
        {
            result_A = (front_A * 0xFF + back_A * 0xFF - front_A * back_A) / 255;
            result_B = (front_B * 0xFF + back_B * 0xFF - front_B * back_B) / 255;
            result_G = (front_G * 0xFF + back_G * 0xFF - front_G * back_G) / 255;
            result_R = (front_R * 0xFF + back_R * 0xFF - front_R * back_R) / 255;
        }
            break;
        case PPE_BLEND_ADD:
        {
            result_A = front_A + back_A;
            result_B = front_B + back_B;
            result_G = front_G + back_G;
            result_R = front_R + back_R;
        }
            break;
        case PPE_BLEND_SUBSTRACT:
        {
            result_A = back_A * (0xFF - front_A) / 255;
            result_B = back_B * (0xFF - front_A) / 255;
            result_G = back_G * (0xFF - front_A) / 255;
            result_R = back_R * (0xFF - front_A) / 255;
        }
            break;
        default:
        {
            PPE_DBG("No such method %d", method);
            assert_param(NULL != NULL);
        }
        break;
    }
    if (result_A > 0xFF)
    {
        result_A = 0xFF;
    }
    if (result_B > 0xFF)
    {
        result_B = 0xFF;
    }
    if (result_G > 0xFF)
    {
        result_G = 0xFF;
    }
    if (result_R > 0xFF)
    {
        result_R = 0xFF;
    }
    uint32_t result_pixel = (result_A << 24) + (result_B << 16) + (result_G << 8) + (result_R);
    
    return result_pixel;
    
}


uint32_t Get_Pixel_From_Position(PPE_InputLayer_Init_Typedef PPE_InputLayer_Init_Struct,uint32_t Position_X,uint32_t Position_Y)
{
    uint8_t Bits_In_Pixel = PPE_Get_Pixel_Size(PPE_InputLayer_Init_Struct.Pixel_Color_Format);
    uint8_t Byte_In_Pixel = Bits_In_Pixel / PPE_BYTE_SIZE;
    if(Bits_In_Pixel >= 8)
    {
        uint32_t pixel_address = PPE_InputLayer_Init_Struct.Layer_Address + \
                                                         (PPE_InputLayer_Init_Struct.Line_Length * Position_Y + \
                                                         Position_X * Bits_In_Pixel) / PPE_BYTE_SIZE;
        uint32_t data_temp = 0;
        uint8_t* source_address = (uint8_t*)pixel_address;
        for(uint32_t counter = 0;counter < Byte_In_Pixel;counter++)
        {
            data_temp += (source_address[counter] << (counter * 8));
        }
        return data_temp;
    }
    else 
    {
        uint32_t pixel_address = PPE_InputLayer_Init_Struct.Layer_Address + \
                                                         (PPE_InputLayer_Init_Struct.Line_Length * Position_Y + \
                                                         Position_X * Bits_In_Pixel) / PPE_BYTE_SIZE;
        uint32_t data_temp = 0;
        uint8_t pixel_val = *(uint8_t*)pixel_address;
        uint8_t offset = ((Position_X * Bits_In_Pixel) % PPE_BYTE_SIZE);
        for(uint32_t counter = 0; counter < Bits_In_Pixel; counter++)
        {
            data_temp += ((pixel_val & (0x01 << (offset + counter))) >> offset);
        }
        return data_temp;
    }
}

void PPE_Simulation(PPE_ResultLayer_Init_Typedef * PPE_ResultLayer_Init_Struct,\
                                            PPE_InputLayer_Init_Typedef  * PPE_InputLayer_Init_Struct,\
                                            uint32_t PPE_InputLyaer_ID_ALL
                                            )
{    
    /*each line of result layer*/
    for(uint32_t Result_Vertical_Counter = PPE_ResultLayer_Init_Struct->Layer_Window_Ymin;Result_Vertical_Counter <= PPE_ResultLayer_Init_Struct->Layer_Window_Ymax;Result_Vertical_Counter++)
    {
        /*each pixel of result layer line*/
        for (uint32_t Result_HoriPixel_Counter = PPE_ResultLayer_Init_Struct->Layer_Window_Xmin;Result_HoriPixel_Counter <= PPE_ResultLayer_Init_Struct->Layer_Window_Xmax;Result_HoriPixel_Counter++)
        {
            if(Result_Vertical_Counter < PPE_ResultLayer_Init_Struct->Layer_Window_Ymin || Result_Vertical_Counter > PPE_ResultLayer_Init_Struct->Layer_Window_Ymax ||\
                Result_HoriPixel_Counter < PPE_ResultLayer_Init_Struct->Layer_Window_Xmin || Result_HoriPixel_Counter > PPE_ResultLayer_Init_Struct->Layer_Window_Xmax)
            {
                continue;
            }
//            PPE_DBG("Result_Vertical_Counter = %d\r\n",Result_Vertical_Counter);
//            PPE_DBG("Result_HoriPixel_Counter = %d\r\n",Result_HoriPixel_Counter);
            
            /*get pixel from each input layer*/
            uint32_t InputLayer_Pixel[PPE_MAX_INPUTLAYER] = {0};
            bool InputLayer_Valid[PPE_MAX_INPUTLAYER] = {0};
            for(uint32_t InputLayer_Counter = 0;InputLayer_Counter < PPE_MAX_INPUTLAYER;InputLayer_Counter++)
            {
                
                /*check if the input layer is enabled*/
                if (!(PPE_InputLyaer_ID_ALL & BIT(InputLayer_Counter)))
                {
                    InputLayer_Pixel[InputLayer_Counter] = 0x0;            // output 0x0 when layer is not disabled
                    continue;
                }
                else
                {
                    /*check if the result corrdinate is in the layer output window*/
                    if((Result_Vertical_Counter < PPE_InputLayer_Init_Struct[InputLayer_Counter].Layer_Window_Ymin) | \
                            (Result_Vertical_Counter > PPE_InputLayer_Init_Struct[InputLayer_Counter].Layer_Window_Ymax))
                    {
                        InputLayer_Pixel[InputLayer_Counter] = 0x0;            // output 0x0 when outside layer window
                        InputLayer_Valid[InputLayer_Counter] = false;
                        continue;
                    }
                    else if ((Result_HoriPixel_Counter < PPE_InputLayer_Init_Struct[InputLayer_Counter].Layer_Window_Xmin) | \
                                        (Result_HoriPixel_Counter > PPE_InputLayer_Init_Struct[InputLayer_Counter].Layer_Window_Xmax))
                    {
                        InputLayer_Pixel[InputLayer_Counter] = 0x0;            // output 0x0 when outside layer window
                        InputLayer_Valid[InputLayer_Counter] = false;
                        continue;    
                    }
                    else
                    {
                        /*process the negative value*/                        
                        long long int Matrix_F11 =                          (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E11 & BIT31)?\
                                                                (-1)*(0x100000000 - PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E11):\
                                                                                                     (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E11);
                        long long int Matrix_F12 =                       (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E12 & BIT31)?\
                                                                (-1)*(0x100000000 - PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E12):\
                                                                                                     (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E12);;                        
                        long long int Matrix_F13 =                       (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E13 & BIT31)?\
                                                                (-1)*(0x100000000 - PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E13):\
                                                                                                     (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E13);;
                        long long int Matrix_F21 =                       (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E21 & BIT31)?\
                                                                (-1)*(0x100000000 - PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E21):\
                                                                                                     (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E21);;
                        long long int Matrix_F22 =                       (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E22 & BIT31)?\
                                                                (-1)*(0x100000000 - PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E22):\
                                                                                                     (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E22);;
                        long long int Matrix_F23 =                       (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E23 & BIT31)?\
                                                                (-1)*(0x100000000 - PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E23):\
                                                                                                     (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E23);;
                        long long int Matrix_F31 =                       (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E31 & BIT31)?\
                                                                (-1)*(0x100000000 - PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E31):\
                                                                                                     (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E31);;
                        long long int Matrix_F32 =                       (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E32 & BIT31)?\
                                                                (-1)*(0x100000000 - PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E32):\
                                                                                                     (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E32);;
                        long long int Matrix_F33 =                       (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E33 & BIT31)?\
                                                                (-1)*(0x100000000 - PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E33):\
                                                                                                     (PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E33);;    
                        
                        
//                        long long int Matrix_F11 =                       *(int32_t*)&PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E11;
//                        long long int Matrix_F12 =                       *(int32_t*)&PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E12;
//                        long long int Matrix_F13 =                       *(int32_t*)&PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E13;
//                        long long int Matrix_F21 =                       *(int32_t*)&PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E21;
//                        long long int Matrix_F22 =                       *(int32_t*)&PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E22;
//                        long long int Matrix_F23 =                       *(int32_t*)&PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E23;
//                        long long int Matrix_F31 =                       *(int32_t*)&PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E31;
//                        long long int Matrix_F32 =                       *(int32_t*)&PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E32;
//                        long long int Matrix_F33 =                       *(int32_t*)&PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E33;
//                        PPE_DBG("Matrix_F11 is %x\r\n",(int)Matrix_F11);
//                        PPE_DBG("Matrix_F12 is %x\r\n",(int)Matrix_F12);
//                        PPE_DBG("Matrix_F13 is %x\r\n",(int)Matrix_F13);
//                        PPE_DBG("Matrix_F21 is %x\r\n",(int)Matrix_F21);
//                        PPE_DBG("Matrix_F22 is %x\r\n",(int)Matrix_F22);
//                        PPE_DBG("Matrix_F23 is %x\r\n",(int)Matrix_F23);
//                        PPE_DBG("Matrix_F31 is %x\r\n",(int)Matrix_F31);
//                        PPE_DBG("Matrix_F32 is %x\r\n",(int)Matrix_F32);
//                        PPE_DBG("Matrix_F33 is %x\r\n",(int)Matrix_F33);
                        
                        long long int Inputlayer_Coordinate_X_Full = Matrix_F11 * Result_HoriPixel_Counter + Matrix_F12 * Result_Vertical_Counter + Matrix_F13 * 1;
                        long long int Inputlayer_Coordinate_Y_Full = Matrix_F21 * Result_HoriPixel_Counter + Matrix_F22 * Result_Vertical_Counter + Matrix_F23 * 1;
                        long long int Inputlayer_Coordinate_Z_Full = Matrix_F31 * Result_HoriPixel_Counter + Matrix_F32 * Result_Vertical_Counter + Matrix_F33 * 1;
//                        uint32_t* data32 = (uint32_t*)&Inputlayer_Coordinate_X_Full;
//                        PPE_DBG("x full %08x %08x", data32[0], data32[1]);
//                        int64_t Inputlayer_Coordinate_X_Full = (int32_t)PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E11 * Result_HoriPixel_Counter + (int32_t)PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E12 * Result_Vertical_Counter + (int32_t)PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E13 * 1;
//                        int64_t Inputlayer_Coordinate_Y_Full = (int32_t)PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E21 * Result_HoriPixel_Counter + (int32_t)PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E22 * Result_Vertical_Counter + (int32_t)PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E23 * 1;
//                        int64_t Inputlayer_Coordinate_Z_Full = (int32_t)PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E31 * Result_HoriPixel_Counter + (int32_t)PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E32 * Result_Vertical_Counter + (int32_t)PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E33 * 1;
//                        PPE_DBG("Matrix_E11 is %x\r\n",PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E11);
//                        PPE_DBG("Matrix_E12 is %x\r\n",PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E12);
//                        PPE_DBG("Matrix_E13 is %x\r\n",PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E13);
//                        PPE_DBG("Matrix_E21 is %x\r\n",PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E21);
//                        PPE_DBG("Matrix_E22 is %x\r\n",PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E22);
//                        PPE_DBG("Matrix_E23 is %x\r\n",PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E23);
//                        PPE_DBG("Matrix_E31 is %x\r\n",PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E31);
//                        PPE_DBG("Matrix_E32 is %x\r\n",PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E32);
//                        PPE_DBG("Matrix_E33 is %x\r\n",PPE_InputLayer_Init_Struct[InputLayer_Counter].Transfer_Matrix_E33);
//                        PPE_DBG("current location %d, %d", Result_HoriPixel_Counter, Result_Vertical_Counter);
//                        PPE_DBG("Inputlayer_Coordinate_X_Full is %d\r\n",Inputlayer_Coordinate_X_Full);
//                        PPE_DBG("Inputlayer_Coordinate_Y_Full is %d\r\n",Inputlayer_Coordinate_Y_Full);
//                        PPE_DBG("Inputlayer_Coordinate_Z_Full is %d\r\n",Inputlayer_Coordinate_Z_Full);
                        
                        float Inputlayer_Coordinate_X;
                        float Inputlayer_Coordinate_Y;
                        if (Inputlayer_Coordinate_Z_Full == 0)
                        {
                            /*absoluely outside the input picture*/
                            Inputlayer_Coordinate_X = (float)0xFFFFFFFF;
                            Inputlayer_Coordinate_Y = (float)0xFFFFFFFF;
                        }
                        else
                        {
                            Inputlayer_Coordinate_X = (float)Inputlayer_Coordinate_X_Full / (float)Inputlayer_Coordinate_Z_Full;
                            Inputlayer_Coordinate_Y = (float)Inputlayer_Coordinate_Y_Full / (float)Inputlayer_Coordinate_Z_Full;
                        }
//                        PPE_DBG("Inputlayer_Coordinate_X is %f\r\n",Inputlayer_Coordinate_X);
//                        PPE_DBG("Inputlayer_Coordinate_Y is %f\r\n",Inputlayer_Coordinate_Y);
                        
                        if (PPE_InputLayer_Init_Struct[InputLayer_Counter].LayerBus_Inc == PPE_AWBURST_FIXED)
                        {
                            PPE_DBG("FIX Burst not support");
                            assert_param(NULL != NULL);
                        }
                        /*check if the input layer cooridnate inside picture*/
                        else
                        {
                            /*check the pixel source*/
                            if (PPE_InputLayer_Init_Struct[InputLayer_Counter].Pixel_Source == PPE_LAYER_SRC_CONST)
                            {
                                if ((Inputlayer_Coordinate_X < -0.5) | (Inputlayer_Coordinate_X >= (PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Width - 0.5)))
                                {
                                    InputLayer_Pixel[InputLayer_Counter] = 0x0;            // output 0x0 when outside layer picture
                                    continue;
                                }
                                else if ((Inputlayer_Coordinate_Y < -0.5) | (Inputlayer_Coordinate_Y >= (PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Height - 0.5)))
                                {
                                    InputLayer_Pixel[InputLayer_Counter] = 0x0;            // output 0x0 when outside layer picture
                                    continue;
                                }
                                else
                                {
                                    InputLayer_Pixel[InputLayer_Counter] = PPE_InputLayer_Init_Struct[InputLayer_Counter].Const_Pixel;            // output constant value ABGR8888
                                }
                                continue;
                            }
                            else if (PPE_InputLayer_Init_Struct[InputLayer_Counter].Source_Interpolation == PPV2_SRC_NEAREST_NEIGHBOUR)
                            {
                                if ((Inputlayer_Coordinate_X < -0.5) | (Inputlayer_Coordinate_X >= (PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Width - 0.5)))
                                {
                                    InputLayer_Pixel[InputLayer_Counter] = 0x0;            // output 0x0 when outside layer picture
                                    InputLayer_Valid[InputLayer_Counter] = false;
                                }
                                else if ((Inputlayer_Coordinate_Y < -0.5) | (Inputlayer_Coordinate_Y >= (PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Height - 0.5)))
                                {
                                    InputLayer_Pixel[InputLayer_Counter] = 0x0;            // output 0x0 when outside layer picture
                                    InputLayer_Valid[InputLayer_Counter] = false;
                                }
                                else
                                {
                                    int x, y;
                                    if (Inputlayer_Coordinate_X == -0.5)
                                    {
                                        x = 0;
                                    }
                                    else
                                    {
                                        x = round(Inputlayer_Coordinate_X);
                                    }
                                    if (Inputlayer_Coordinate_Y == -0.5)
                                    {
                                        y = 0;
                                    }
                                    else
                                    {
                                        y = round(Inputlayer_Coordinate_Y);
                                    }
                                    T_ABGR pix = {.abgr_full = 0};
                                    uint32_t raw_val = Get_Pixel_From_Position(PPE_InputLayer_Init_Struct[InputLayer_Counter], x, y);
                                    pix.abgr_full = Convert_Pixel_Format_to_ABGR8888(raw_val, PPE_InputLayer_Init_Struct[InputLayer_Counter]);
                                    
                                    uint8_t color_key_r_min = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MIN_R;
                                    uint8_t color_key_g_min = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MIN_G;
                                    uint8_t color_key_b_min = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MIN_B;
                                    uint8_t color_key_r_max = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MAX_R;
                                    uint8_t color_key_g_max = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MAX_G;
                                    uint8_t color_key_b_max = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MAX_B;
                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.key_enable)
                                    {
                                        if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Mode == PPE_COLOR_KEY_INSIDE)
                                        {
                                            if (pix.channel.r <= color_key_r_max && pix.channel.b <= color_key_b_max && pix.channel.g <= color_key_g_max &&\
                                                   pix.channel.r >= color_key_r_min && pix.channel.b >= color_key_b_min && pix.channel.g >= color_key_g_min)
                                            {
                                                if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.a_en)
                                                {
                                                    pix.channel.a = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_A;
                                                }
                                                if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.b_en)
                                                {
                                                    pix.channel.b = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_B;
                                                }
                                                if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.g_en)
                                                {
                                                    pix.channel.g = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_G;
                                                }
                                                if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.r_en)
                                                {
                                                    pix.channel.r = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_R;
                                                }
                                            }
                                        }
                                        else if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Mode == PPE_COLOR_KEY_OUTSIDE)
                                        {
                                            if (pix.channel.r > color_key_r_max && pix.channel.b > color_key_b_max && pix.channel.g > color_key_g_max &&\
                                                   pix.channel.r < color_key_r_min && pix.channel.b < color_key_b_min && pix.channel.g < color_key_g_min)
                                            {
                                                if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.a_en)
                                                {
                                                    pix.channel.a = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_A;
                                                }
                                                if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.b_en)
                                                {
                                                    pix.channel.b = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_B;
                                                }
                                                if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.g_en)
                                                {
                                                    pix.channel.g = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_G;
                                                }
                                                if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.r_en)
                                                {
                                                    pix.channel.r = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_R;
                                                }
                                            }
                                        }
                                    }
                                    
                                    uint32_t constant_reg_A = (PPE_InputLayer_Init_Struct[InputLayer_Counter].Const_Pixel >> 24) & 0xFF;
                                    uint32_t constant_reg_B = (PPE_InputLayer_Init_Struct[InputLayer_Counter].Const_Pixel >> 16) & 0xFF;
                                    uint32_t constant_reg_G = (PPE_InputLayer_Init_Struct[InputLayer_Counter].Const_Pixel >> 8) & 0xFF;
                                    uint32_t constant_reg_R = (PPE_InputLayer_Init_Struct[InputLayer_Counter].Const_Pixel >> 0) & 0xFF;
                                    pix.channel.a = (uint8_t)((constant_reg_A * pix.channel.a) / 255);
                                    pix.channel.b = (uint8_t)((constant_reg_B * pix.channel.b) / 255);
                                    pix.channel.g = (uint8_t)((constant_reg_G * pix.channel.g) / 255);
                                    pix.channel.r = (uint8_t)((constant_reg_R * pix.channel.r) / 255);
                                    InputLayer_Pixel[InputLayer_Counter] = pix.abgr_full;
                                    InputLayer_Valid[InputLayer_Counter] = true;
                                    //PPE_DBG("layer%d 1x1 result %x", InputLayer_Counter, InputLayer_Pixel[InputLayer_Counter]);
                                }
                                continue;
                            }
                            else if (PPE_InputLayer_Init_Struct[InputLayer_Counter].Source_Interpolation == PPV2_SRC_BILINEAR)
                            {
                                if ((Inputlayer_Coordinate_X < -1) | (Inputlayer_Coordinate_X >= (PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Width)))
                                {
                                    InputLayer_Pixel[InputLayer_Counter] = 0x0;            // output 0x0 when outside layer picture
                                    InputLayer_Valid[InputLayer_Counter] = false;
                                }
                                else if ((Inputlayer_Coordinate_Y < -1) | (Inputlayer_Coordinate_Y >= (PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Height)))
                                {
                                    InputLayer_Pixel[InputLayer_Counter] = 0x0;            // output 0x0 when outside layer picture
                                    InputLayer_Valid[InputLayer_Counter] = false;
                                }
                                else
                                {
                                    PPE_DBG("float %f, %f", Inputlayer_Coordinate_X, Inputlayer_Coordinate_Y);
                                    T_ABGR pix1, pix2, pix3, pix4;
                                    int32_t x1 = (int)(Inputlayer_Coordinate_X);
                                    int32_t x2 = x1 + 1;
                                    int32_t y1 = (int)(Inputlayer_Coordinate_Y);
                                    int32_t y2 = y1 + 1;
                                    if (Inputlayer_Coordinate_X < 0)
                                    {
                                        x2 = x1 - 1;
                                    }
                                    else
                                    {
                                        x2 = x1 + 1;
                                    }
                                    if (Inputlayer_Coordinate_Y < 0)
                                    {
                                        y2 = y1 - 1;
                                    }
                                    else
                                    {
                                        y2 = y1 + 1;
                                    }
                                    /*check 2X2 matrix or 1X1 matrix*/
                                    
                                    if (x1 < 0 || x1 > PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Width - 1)
                                    {
                                        pix1.abgr_full = 0;
                                        pix3.abgr_full = 0;
                                    }
                                    else
                                    {
                                        if (y1 < 0 || y1 > PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Height - 1)
                                        {
                                            pix1.abgr_full = 0;
                                        }
                                        else
                                        {
                                            pix1.abgr_full = Get_Pixel_From_Position(PPE_InputLayer_Init_Struct[InputLayer_Counter], x1, y1);
                                            pix1.abgr_full = Convert_Pixel_Format_to_ABGR8888(pix1.abgr_full, PPE_InputLayer_Init_Struct[InputLayer_Counter]);
                                        }
                                        if (y2 < 0 || y2 > PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Height - 1)
                                        {
                                            pix3.abgr_full = 0;
                                        }
                                        else
                                        {
                                            pix3.abgr_full = Get_Pixel_From_Position(PPE_InputLayer_Init_Struct[InputLayer_Counter], x1, y2);
                                            pix3.abgr_full = Convert_Pixel_Format_to_ABGR8888(pix3.abgr_full, PPE_InputLayer_Init_Struct[InputLayer_Counter]);
                                        }
                                    }
                                    
                                    if (x2 < 0 || x2 > PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Width - 1)
                                    {
                                        pix2.abgr_full = 0;
                                        pix4.abgr_full = 0;
                                    }
                                    else
                                    {
                                        if (y1 < 0 || y1 > PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Height - 1)
                                        {
                                            pix2.abgr_full = 0;
                                        }
                                        else
                                        {
                                            pix2.abgr_full = Get_Pixel_From_Position(PPE_InputLayer_Init_Struct[InputLayer_Counter], x2, y1);
                                            pix2.abgr_full = Convert_Pixel_Format_to_ABGR8888(pix2.abgr_full, PPE_InputLayer_Init_Struct[InputLayer_Counter]);
                                        }
                                        if (y2 < 0 || y2 > PPE_InputLayer_Init_Struct[InputLayer_Counter].Pic_Height - 1)
                                        {
                                            pix4.abgr_full = 0;
                                        }
                                        else
                                        {
                                            pix4.abgr_full = Get_Pixel_From_Position(PPE_InputLayer_Init_Struct[InputLayer_Counter], x2, y2);
                                            pix4.abgr_full = Convert_Pixel_Format_to_ABGR8888(pix4.abgr_full, PPE_InputLayer_Init_Struct[InputLayer_Counter]);
                                        }
                                    }
                                    
    //                                if(InputLayer_Counter == 0)
    //                                {
    //                                    PPE_DBG("Matrix_2X2_00_Coordinate[0] is %d\r\n",Matrix_2X2_00_Coordinate[0]);
    //                                    PPE_DBG("Matrix_2X2_00_Coordinate[1] is %d\r\n",Matrix_2X2_00_Coordinate[1]);
    //                                }
                                    
    //                                PPE_DBG("Matrix_2X2_00_Coordinate[%d,%d]\r\n",Matrix_2X2_00_Coordinate[0],Matrix_2X2_00_Coordinate[1]);
    //                                PPE_DBG("Matrix_2X2_01_Coordinate[%d,%d]\r\n",Matrix_2X2_01_Coordinate[0],Matrix_2X2_01_Coordinate[1]);
    //                                PPE_DBG("Matrix_2X2_10_Coordinate[%d,%d]\r\n",Matrix_2X2_10_Coordinate[0],Matrix_2X2_10_Coordinate[1]);
    //                                PPE_DBG("Matrix_2X2_11_Coordinate[%d,%d]\r\n",Matrix_2X2_11_Coordinate[0],Matrix_2X2_11_Coordinate[1]);
                                    
                                    /*Get a 2X2 pixel matrix */
    //                                PPE_DBG("Input_layer_pixel_temp0_0[%d,%d] = %x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_temp0_0);
    //                                PPE_DBG("Input_layer_pixel_temp0_1[%d,%d] = %x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_temp0_1);
    //                                PPE_DBG("Input_layer_pixel_temp1_0[%d,%d] = %x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_temp1_0);
    //                                PPE_DBG("Input_layer_pixel_temp1_1[%d,%d] = %x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_temp1_1);
    //                                if(InputLayer_Counter == 0)
    //                                {
    //                                    PPE_DBG("Input_layer_pixel_temp0_0[%d,%d] = %x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_temp0_0);
    //                                    PPE_DBG("Input_layer_pixel_temp0_1[%d,%d] = %x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_temp0_1);
    //                                    PPE_DBG("Input_layer_pixel_temp1_0[%d,%d] = %x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_temp1_0);
    //                                    PPE_DBG("Input_layer_pixel_temp1_1[%d,%d] = %x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_temp1_1);
    //                                }
        
                                    /*convert 2x2 matrix into ABGR8888 color format*/
                                    
    //                                PPE_DBG("Input_layer_pixel_00_ABGR8888[%d,%d] now is 0x%x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_00_ABGR8888);
    //                                PPE_DBG("Input_layer_pixel_01_ABGR8888[%d,%d] now is 0x%x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_01_ABGR8888);
    //                                PPE_DBG("Input_layer_pixel_10_ABGR8888[%d,%d] now is 0x%x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_10_ABGR8888);
    //                                PPE_DBG("Input_layer_pixel_11_ABGR8888[%d,%d] now is 0x%x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_11_ABGR8888);
    //                                if(InputLayer_Counter == 0)
    //                                {
    //                                    PPE_DBG("Input_layer_pixel_00_ABGR8888[%d,%d] now is 0x%x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_00_ABGR8888);
    //                                    PPE_DBG("Input_layer_pixel_01_ABGR8888[%d,%d] now is 0x%x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_01_ABGR8888);
    //                                    PPE_DBG("Input_layer_pixel_10_ABGR8888[%d,%d] now is 0x%x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_10_ABGR8888);
    //                                    PPE_DBG("Input_layer_pixel_11_ABGR8888[%d,%d] now is 0x%x\r\n",Result_HoriPixel_Counter,Result_Vertical_Counter,Input_layer_pixel_11_ABGR8888);
    //                                }
                                                                    
                                    /*compare with color key*/
                                    uint8_t color_key_r_min = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MIN_R;
                                    uint8_t color_key_g_min = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MIN_G;
                                    uint8_t color_key_b_min = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MIN_B;
                                    uint8_t color_key_r_max = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MAX_R;
                                    uint8_t color_key_g_max = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MAX_G;
                                    uint8_t color_key_b_max = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_MAX_B;
                                    T_ABGR* pixs[4] = {&pix1, &pix2, &pix3, &pix4};
                                    PPE_DBG("colors %08x %08x %08x %08x", pix1.abgr_full, pix2.abgr_full, pix3.abgr_full, pix4.abgr_full);
                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.key_enable)
                                    {
                                        if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Mode == PPE_COLOR_KEY_INSIDE)
                                        {
                                            for(int i = 0; i < 4; i++)
                                            {
                                                if (pixs[i]->channel.r <= color_key_r_max && pixs[i]->channel.b <= color_key_b_max && pixs[i]->channel.g <= color_key_g_max &&\
                                                       pixs[i]->channel.r >= color_key_r_min && pixs[i]->channel.b >= color_key_b_min && pixs[i]->channel.g >= color_key_g_min)
                                                {
                                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.a_en)
                                                    {
                                                        pixs[i]->channel.a = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_A;
                                                    }
                                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.b_en)
                                                    {
                                                        pixs[i]->channel.b = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_B;
                                                    }
                                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.g_en)
                                                    {
                                                        pixs[i]->channel.g = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_G;
                                                    }
                                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.r_en)
                                                    {
                                                        pixs[i]->channel.r = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_R;
                                                    }
                                                }
                                            }
                                        }
                                        else if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Mode == PPE_COLOR_KEY_OUTSIDE)
                                        {
                                            for(int i = 0; i < 4; i++)
                                            {
                                                if (pixs[i]->channel.r <= color_key_r_max && pixs[i]->channel.b <= color_key_b_max && pixs[i]->channel.g <= color_key_g_max &&\
                                                       pixs[i]->channel.r >= color_key_r_min && pixs[i]->channel.b >= color_key_b_min && pixs[i]->channel.g >= color_key_g_min)
                                                {
                                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.a_en)
                                                    {
                                                        pixs[i]->channel.a = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_A;
                                                    }
                                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.b_en)
                                                    {
                                                        pixs[i]->channel.b = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_B;
                                                    }
                                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.g_en)
                                                    {
                                                        pixs[i]->channel.g = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_G;
                                                    }
                                                    if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Enable.channel_en.r_en)
                                                    {
                                                        pixs[i]->channel.r = PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Replace_R;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
//                                    T_ABGR * Old_Pixel_Array_2x2[4] = {Old_Pixel_0_0,Old_Pixel_0_1,Old_Pixel_1_0,Old_Pixel_1_1};
//                                    for(uint32_t counter=0;counter < 4;counter++)
//                                    {
//                                        if(PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Mode == PPE_COLOR_KEY_INSIDE)
//                                        {
//                                            if ((Old_Pixel_Array_2x2[counter]->r < color_key_r_max) && (Old_Pixel_Array_2x2[counter]->r >= color_key_r_min))
//                                            {
//                                                if ((Old_Pixel_Array_2x2[counter]->g < color_key_g_max) && (Old_Pixel_Array_2x2[counter]->g >= color_key_g_min))
//                                                {
//                                                    if ((Old_Pixel_Array_2x2[counter]->b < color_key_b_max) && (Old_Pixel_Array_2x2[counter]->b >= color_key_b_min))
//                                                    {
//    //                                                    PPE_DBG("Old_Pixel_Array_2x2[before] now is %x\r\n",*(uint32_t *)Old_Pixel_Array_2x2[counter]);
//                                                        Old_Pixel_Array_2x2[counter]->a = 0;
//                                                        Old_Pixel_Array_2x2[counter]->r = 0;
//                                                        Old_Pixel_Array_2x2[counter]->g = 0;
//                                                        Old_Pixel_Array_2x2[counter]->b = 0;
//    //                                                    PPE_DBG("Old_Pixel_Array_2x2[after] now is %x\r\n",*(uint32_t *)Old_Pixel_Array_2x2[counter]);
//                                                    }
//                                                }
//                                            }
//                                        }
//                                        else if (PPE_InputLayer_Init_Struct[InputLayer_Counter].Color_Key_Mode == PPE_COLOR_KEY_OUTSIDE)
//                                        {
//                                            if ((Old_Pixel_Array_2x2[counter]->r >= color_key_r_max)|| (Old_Pixel_Array_2x2[counter]->r < color_key_r_min))
//                                            {
//                                                Old_Pixel_Array_2x2[counter]->a = 0;
//                                                Old_Pixel_Array_2x2[counter]->r = 0;
//                                                Old_Pixel_Array_2x2[counter]->g = 0;
//                                                Old_Pixel_Array_2x2[counter]->b = 0;
//                                            }
//                                            else if ((Old_Pixel_Array_2x2[counter]->g >= color_key_g_max)|| (Old_Pixel_Array_2x2[counter]->g < color_key_g_min))
//                                            {
//                                                Old_Pixel_Array_2x2[counter]->a = 0;
//                                                Old_Pixel_Array_2x2[counter]->r = 0;
//                                                Old_Pixel_Array_2x2[counter]->g = 0;
//                                                Old_Pixel_Array_2x2[counter]->b = 0;
//                                            }
//                                            else if ((Old_Pixel_Array_2x2[counter]->b >= color_key_b_max)|| (Old_Pixel_Array_2x2[counter]->b < color_key_b_min))
//                                            {
//                                                Old_Pixel_Array_2x2[counter]->a = 0;
//                                                Old_Pixel_Array_2x2[counter]->r = 0;
//                                                Old_Pixel_Array_2x2[counter]->g = 0;
//                                                Old_Pixel_Array_2x2[counter]->b = 0;
//                                            }
//                                        }
//                                    }
                                    
    //                                PPE_DBG("Input_layer_pixel_00_ABGR8888 after color key now is 0x%x\r\n",Input_layer_pixel_00_ABGR8888);
    //                                PPE_DBG("Input_layer_pixel_01_ABGR8888 after color key now is 0x%x\r\n",Input_layer_pixel_01_ABGR8888);
    //                                PPE_DBG("Input_layer_pixel_10_ABGR8888 after color key now is 0x%x\r\n",Input_layer_pixel_10_ABGR8888);
    //                                PPE_DBG("Input_layer_pixel_11_ABGR8888 after color key now is 0x%x\r\n",Input_layer_pixel_11_ABGR8888);
                                    
                                    /*calculate with A from const, Am * Ac / 255*/
                                    uint32_t constant_reg_A = (PPE_InputLayer_Init_Struct[InputLayer_Counter].Const_Pixel >> 24) & 0xFF;
                                    uint32_t constant_reg_B = (PPE_InputLayer_Init_Struct[InputLayer_Counter].Const_Pixel >> 16) & 0xFF;
                                    uint32_t constant_reg_G = (PPE_InputLayer_Init_Struct[InputLayer_Counter].Const_Pixel >> 8) & 0xFF;
                                    uint32_t constant_reg_R = (PPE_InputLayer_Init_Struct[InputLayer_Counter].Const_Pixel >> 0) & 0xFF;
                                    pix1.channel.a = (uint8_t)((constant_reg_A * pix1.channel.a) / 255);
                                    pix2.channel.a = (uint8_t)((constant_reg_A * pix2.channel.a) / 255);
                                    pix3.channel.a = (uint8_t)((constant_reg_A * pix3.channel.a) / 255);
                                    pix4.channel.a = (uint8_t)((constant_reg_A * pix4.channel.a) / 255);
                                    
                                    pix1.channel.b = (uint8_t)((constant_reg_B * pix1.channel.b) / 255);
                                    pix2.channel.b = (uint8_t)((constant_reg_B * pix2.channel.b) / 255);
                                    pix3.channel.b = (uint8_t)((constant_reg_B * pix3.channel.b) / 255);
                                    pix4.channel.b = (uint8_t)((constant_reg_B * pix4.channel.b) / 255);
                                    
                                    pix1.channel.g = (uint8_t)((constant_reg_G * pix1.channel.g) / 255);
                                    pix2.channel.g = (uint8_t)((constant_reg_G * pix2.channel.g) / 255);
                                    pix3.channel.g = (uint8_t)((constant_reg_G * pix3.channel.g) / 255);
                                    pix4.channel.g = (uint8_t)((constant_reg_G * pix4.channel.g) / 255);
                                    
                                    pix1.channel.r = (uint8_t)((constant_reg_R * pix1.channel.r) / 255);
                                    pix2.channel.r = (uint8_t)((constant_reg_R * pix2.channel.r) / 255);
                                    pix3.channel.r = (uint8_t)((constant_reg_R * pix3.channel.r) / 255);
                                    pix4.channel.r = (uint8_t)((constant_reg_R * pix4.channel.r) / 255);
                                    
    //                                PPE_DBG("Input_layer_pixel_00_ABGR8888 after  Am*Ac/255  now is 0x%x\r\n",Input_layer_pixel_00_ABGR8888);
    //                                PPE_DBG("Input_layer_pixel_01_ABGR8888 after  Am*Ac/255  now is 0x%x\r\n",Input_layer_pixel_01_ABGR8888);
    //                                PPE_DBG("Input_layer_pixel_10_ABGR8888 after  Am*Ac/255  now is 0x%x\r\n",Input_layer_pixel_10_ABGR8888);
    //                                PPE_DBG("Input_layer_pixel_11_ABGR8888 after  Am*Ac/255  now is 0x%x\r\n",Input_layer_pixel_11_ABGR8888);

                                    /*mix the 2X2 matrix into one pixel*/
                                    T_ABGR calculate_result;

                                        /*PPE2.0 Average pixel*/ /*max bit = 32 + 8 + 3 = 43*/                                                                
//                                        PPE_DBG("mid %x - %x = %x", Inputlayer_Coordinate_X_Full,  x1 * 65536, Inputlayer_Coordinate_X_Full * 65536 / Inputlayer_Coordinate_Z_Full - x1 * 65536);
                                    uint32_t x_ratio = abs((int)((Inputlayer_Coordinate_X_Full % Inputlayer_Coordinate_Z_Full) * 65536 / Inputlayer_Coordinate_Z_Full));
                                    uint32_t y_ratio = abs((int)((Inputlayer_Coordinate_Y_Full % Inputlayer_Coordinate_Z_Full) * 65536 / Inputlayer_Coordinate_Z_Full));
//                                    uint64_t x_ratio = abs((int)(((Inputlayer_Coordinate_X_Full % Inputlayer_Coordinate_Z_Full) * 65536) / Inputlayer_Coordinate_Z_Full));
//                                    uint64_t y_ratio = abs((int)(((Inputlayer_Coordinate_Y_Full % Inputlayer_Coordinate_Z_Full) * 65536) / Inputlayer_Coordinate_Z_Full));
    //                                PPE_DBG("x_ratio now is %d\r\n",x_ratio);
    //                                PPE_DBG("y_ratio now is %d\r\n",y_ratio);

    //                                /*PPE1.0 Average pixel*/
//                                    uint32_t x_ratio = abs(((int)(Inputlayer_Coordinate_X * 65536)) - x1 * 65536);
//                                    uint32_t y_ratio = abs(((int)(Inputlayer_Coordinate_Y * 65536)) - y1 * 65536);
    //                                calculate_result.a = (((65536 - x_ratio) * ((((65536 - y_ratio) * Old_Pixel_0_0->a) + (y_ratio * Old_Pixel_1_0->a)) >> 16))    + \
    //                                                                            (         x_ratio  * ((((65536 - y_ratio) * Old_Pixel_0_1->a) + (y_ratio * Old_Pixel_1_1->a)) >> 16))) >> 16;
    //                                calculate_result.r = (((65536 - x_ratio) * ((((65536 - y_ratio) * Old_Pixel_0_0->r) + (y_ratio * Old_Pixel_1_0->r)) >> 16))    + \
    //                                                                            (         x_ratio  * ((((65536 - y_ratio) * Old_Pixel_0_1->r) + (y_ratio * Old_Pixel_1_1->r)) >> 16))) >> 16;
    //                                calculate_result.g = (((65536 - x_ratio) * ((((65536 - y_ratio) * Old_Pixel_0_0->g) + (y_ratio * Old_Pixel_1_0->g)) >> 16))    + \
    //                                                                            (         x_ratio  * ((((65536 - y_ratio) * Old_Pixel_0_1->g) + (y_ratio * Old_Pixel_1_1->g)) >> 16))) >> 16;
    //                                calculate_result.b = (((65536 - x_ratio) * ((((65536 - y_ratio) * Old_Pixel_0_0->b) + (y_ratio * Old_Pixel_1_0->b)) >> 16))    + \
    //                                                                            (         x_ratio  * ((((65536 - y_ratio) * Old_Pixel_0_1->b) + (y_ratio * Old_Pixel_1_1->b)) >> 16))) >> 16;        
                                    
                                    calculate_result.channel.a = (((uint64_t)pix1.channel.a * (65536 - x_ratio) + (uint64_t)pix2.channel.a * x_ratio) * (65536 - y_ratio) + \
                                        ((uint64_t)pix3.channel.a * (65536 - x_ratio) + (uint64_t)pix4.channel.a * x_ratio) * y_ratio) / 65536 / 65536;
                                    calculate_result.channel.b = (((uint64_t)pix1.channel.b * (65536 - x_ratio) + (uint64_t)pix2.channel.b * x_ratio) * (65536 - y_ratio) + \
                                        ((uint64_t)pix3.channel.b * (65536 - x_ratio) + (uint64_t)pix4.channel.b * x_ratio) * y_ratio) / 65536 / 65536;
                                    calculate_result.channel.g = (((uint64_t)pix1.channel.g * (65536 - x_ratio) + (uint64_t)pix2.channel.g * x_ratio) * (65536 - y_ratio) + \
                                        ((uint64_t)pix3.channel.g * (65536 - x_ratio) + (uint64_t)pix4.channel.g * x_ratio) * y_ratio) / 65536 / 65536;
                                    calculate_result.channel.r = (((uint64_t)pix1.channel.r * (65536 - x_ratio) + (uint64_t)pix2.channel.r * x_ratio) * (65536 - y_ratio) + \
                                        ((uint64_t)pix3.channel.r * (65536 - x_ratio) + (uint64_t)pix4.channel.r * x_ratio) * y_ratio) / 65536 / 65536;
                                    InputLayer_Pixel[InputLayer_Counter] = calculate_result.abgr_full;
                                    InputLayer_Valid[InputLayer_Counter] = true;
//                                PPE_DBG("(*(uint32_t*)(&calculate_result)) now is 0x%x\r\n",(*(uint32_t*)(&calculate_result)));
//                                if(InputLayer_Counter == 0)
//                                {
//                                    PPE_DBG("(*(uint32_t*)(&calculate_result)) now is 0x%x\r\n",(*(uint32_t*)(&calculate_result)));
//                                }
PPE_DBG("x_top %d, y_top %d, bot %d", TRACE_DOUBLE(Inputlayer_Coordinate_X_Full * 1.0f), TRACE_DOUBLE(Inputlayer_Coordinate_Y_Full* 1.0f), (Inputlayer_Coordinate_Z_Full* 1.0f));
PPE_DBG("x_ratio %d, y_ratio %d", x_ratio, y_ratio);
PPE_DBG("x1 %d, x2 %d, y1 %d, y2 %d", x1, x2, y1 ,y2);
PPE_DBG("p1 %x, p2 %x, p3 %x, p4 %x", pix1.abgr_full, pix2.abgr_full, pix2.abgr_full, pix2.abgr_full);
PPE_DBG("mix %x", calculate_result);
                                }
                            }
                        }
                    }
                }
            }
            
            /*blend the pixel of each input layer*/
            uint32_t Result_Layer_ABGR8888_temp = 0;
            bool background_en = false;
            if (background_en)
            {
                for(uint32_t InputLayer_Counter =0;InputLayer_Counter < PPE_MAX_INPUTLAYER;InputLayer_Counter++)
                {
                    if (InputLayer_Valid[InputLayer_Counter])
                    {
                        //PPE_DBG("before fg %x, bg %x, method %d", InputLayer_Pixel[InputLayer_Counter], Result_Layer_ABGR8888_temp, PPE_InputLayer_Init_Struct[InputLayer_Counter].Blend_Method);
                        Result_Layer_ABGR8888_temp = blend_2pixel_ABGR8888(Result_Layer_ABGR8888_temp,InputLayer_Pixel[InputLayer_Counter], PPE_InputLayer_Init_Struct[InputLayer_Counter].Blend_Method);
                        //PPE_DBG("after bg %x (%d, %d)", Result_Layer_ABGR8888_temp, Result_HoriPixel_Counter, Result_Vertical_Counter);
                    }
                    else
                    {
                        //PPE_DBG("layer%d no valid at (%d, %d)", InputLayer_Counter, Result_HoriPixel_Counter, Result_Vertical_Counter);
                    }
                }
            }
            else
            {
                Result_Layer_ABGR8888_temp = InputLayer_Pixel[0];
                for(uint32_t InputLayer_Counter =1;InputLayer_Counter < PPE_MAX_INPUTLAYER;InputLayer_Counter++)
                {
                    if (InputLayer_Valid[InputLayer_Counter])
                    {
                        PPE_DBG("before fg %x, bg %x, method %d", InputLayer_Pixel[InputLayer_Counter], Result_Layer_ABGR8888_temp, PPE_InputLayer_Init_Struct[InputLayer_Counter].Blend_Method);
                        Result_Layer_ABGR8888_temp = blend_2pixel_ABGR8888(Result_Layer_ABGR8888_temp,InputLayer_Pixel[InputLayer_Counter], PPE_InputLayer_Init_Struct[InputLayer_Counter].Blend_Method);
                        PPE_DBG("after bg %x (%d, %d)", Result_Layer_ABGR8888_temp, Result_HoriPixel_Counter, Result_Vertical_Counter);
                    }
                    else
                    {
                        PPE_DBG("layer%d no valid at (%d, %d)", InputLayer_Counter, Result_HoriPixel_Counter, Result_Vertical_Counter);
                    }
                }
            }
//            while(1);
//            PPE_DBG("result_ABGR8888_temp = 0x%x\r\n",Result_Layer_ABGR8888_temp);
            
            
            /*get the result layer line address*/
            uint32_t Result_Line_Start_Addr = PPE_ResultLayer_Init_Struct->Layer_Address + \
                                                                                PPE_ResultLayer_Init_Struct->Line_Length * Result_Vertical_Counter / PPE_BYTE_SIZE;
            uint32_t Result_Layer_Addr_temp = Result_Line_Start_Addr;
            uint32_t Result_Layer_Byte_In_Pixel = PPE_Get_Pixel_Size(PPE_ResultLayer_Init_Struct->Color_Format) / PPE_BYTE_SIZE;
            /*get the result layer pixel size*/            
            
            /*get the result layer pixel address*/
            if (PPE_ResultLayer_Init_Struct->LayerBus_Inc == PPE_AWBURST_FIXED)
            {
                if (PPE_ResultLayer_Init_Struct->Color_Format == PPE_ABGR8888)
                {
                    Result_Layer_Addr_temp = PPE_ResultLayer_Init_Struct->Layer_Address;
                }
                else
                {
                    PPE_DBG("Error: This output color format is not supported in Fixed Simulation, It will be simmulated in increment !!\r\n");
                    Result_Layer_Addr_temp += Result_HoriPixel_Counter * Result_Layer_Byte_In_Pixel;
                }
            }
            else
            {
                Result_Layer_Addr_temp += Result_HoriPixel_Counter * Result_Layer_Byte_In_Pixel;
            }
            
            
            /*convert ABGR8888 to result format and write it into memory*/
            uint8_t* byte_pointer_temp = (uint8_t *)Result_Layer_Addr_temp;
//            PPE_DBG("result data is %x \r\n",Result_Layer_ABGR8888_temp);
            if(PPE_ResultLayer_Init_Struct->Color_Format == PPE_ARGB8888)
            {
                /*output ARGB8888*/
                byte_pointer_temp[3] = (Result_Layer_ABGR8888_temp >> 24)& 0xFF;                
                byte_pointer_temp[2] = (Result_Layer_ABGR8888_temp >> 0) & 0xFF;
                byte_pointer_temp[1] = (Result_Layer_ABGR8888_temp >> 8) & 0xFF;
                byte_pointer_temp[0] = (Result_Layer_ABGR8888_temp >> 16)& 0xFF;

            }
            else if(PPE_ResultLayer_Init_Struct->Color_Format == PPE_ABGR8888)
            {
                /*output PPE_ABGR8888*/
                byte_pointer_temp[3] = (Result_Layer_ABGR8888_temp >> 24)& 0xFF;                
                byte_pointer_temp[2] = (Result_Layer_ABGR8888_temp >> 16) & 0xFF;
                byte_pointer_temp[1] = (Result_Layer_ABGR8888_temp >> 8) & 0xFF;
                byte_pointer_temp[0] = (Result_Layer_ABGR8888_temp >> 0)& 0xFF;

            }
            else if(PPE_ResultLayer_Init_Struct->Color_Format == PPE_RGB888)
            {
                /*output PPE_RGB888*/
                byte_pointer_temp[2] = (Result_Layer_ABGR8888_temp >> 0) & 0xFF;
                byte_pointer_temp[1] = (Result_Layer_ABGR8888_temp >> 8) & 0xFF;
                byte_pointer_temp[0] = (Result_Layer_ABGR8888_temp >> 16)& 0xFF;            
            }
            else if(PPE_ResultLayer_Init_Struct->Color_Format == PPE_BGR888)
            {
                /*output PPE_BGR888*/
                byte_pointer_temp[2] = (Result_Layer_ABGR8888_temp >> 16) & 0xFF;
                byte_pointer_temp[1] = (Result_Layer_ABGR8888_temp >> 8) & 0xFF;
                byte_pointer_temp[0] = (Result_Layer_ABGR8888_temp >> 0)& 0xFF;            
            }
            else if(PPE_ResultLayer_Init_Struct->Color_Format == PPE_RGB565)
            {
                /*output PPE_RGB565*/
                byte_pointer_temp[1] = (((Result_Layer_ABGR8888_temp >> 0) & 0xF8) >> 0) + (((Result_Layer_ABGR8888_temp >> 8)  & 0xE0) >> 5);
                byte_pointer_temp[0] = (((Result_Layer_ABGR8888_temp >> 8) & 0x1C) << 3) + (((Result_Layer_ABGR8888_temp >> 16) & 0xF8) >> 3);
            }
            else if(PPE_ResultLayer_Init_Struct->Color_Format == PPE_BGR565)
            {
                /*output PPE_BGR565*/
                byte_pointer_temp[1] = (((Result_Layer_ABGR8888_temp >> 16) & 0xF8) >> 0) + (((Result_Layer_ABGR8888_temp >> 8)  & 0xE0) >> 5);
                byte_pointer_temp[0] = (((Result_Layer_ABGR8888_temp >> 8) & 0x1C) << 3) + (((Result_Layer_ABGR8888_temp >> 0) & 0xF8) >> 3);
            }
            else if(PPE_ResultLayer_Init_Struct->Color_Format == PPE_RGB565_S)
            {
                /*output PPE_RGB565_S*/
                byte_pointer_temp[0] = (((Result_Layer_ABGR8888_temp >> 0) & 0xF8) >> 0) + (((Result_Layer_ABGR8888_temp >> 8)  & 0xE0) >> 5);
                byte_pointer_temp[1] = (((Result_Layer_ABGR8888_temp >> 8) & 0x1C) << 3) + (((Result_Layer_ABGR8888_temp >> 16) & 0xF8) >> 3);
            }
            else if(PPE_ResultLayer_Init_Struct->Color_Format == PPE_BGR565_S)
            {
                /*output PPE_BGR565_S*/
                byte_pointer_temp[0] = (((Result_Layer_ABGR8888_temp >> 16) & 0xF8) >> 0) + (((Result_Layer_ABGR8888_temp >> 8)  & 0xE0) >> 5);
                byte_pointer_temp[1] = (((Result_Layer_ABGR8888_temp >> 8) & 0x1C) << 3) + (((Result_Layer_ABGR8888_temp >> 0) & 0xF8) >> 3);
            }
            else
            {
                PPE_DBG("error this output pixel format is not supported in simulation yet ! \r\n");
            }            
        }
    }
    PPE_InputLayer_Init_Struct[1].Index_Table = NULL;
}
