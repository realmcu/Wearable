#ifndef _RTL876X_MODULE_LCD_TE_H_
#define _RTL876X_MODULE_LCD_TE_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "stdint.h"

void lcd_te_device_init(void);
void lcd_te_enable(void);
void lcd_te_disable(void);
void lcd_frame_sync_handler(void);
void lcd_te_enter_dlps(void);

#ifdef __cplusplus
}
#endif

#endif /* _RTL876X_MODULE_LCD_TE_H_ */
