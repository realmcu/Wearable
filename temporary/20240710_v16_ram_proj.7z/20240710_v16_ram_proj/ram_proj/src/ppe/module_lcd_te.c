#include "board.h"
#include "trace.h"
#include "os_timer.h"
#include "os_mem.h"
#include "rtl876x_rcc.h"
#include "rtl876x_gpio.h"
#include "rtl876x_nvic.h"
#include "app_msg.h"
#include "module_lcd_te.h"
#include "vector_table.h"
#include "rtl876x_pinmux.h"
#if defined TARGET_RTL8763E
#include "gui_core.h"
#include "gui_task.h"
#else
#include "rtl_lcdc_dbic.h"
#include "module_lcdc.h"
#endif

#if defined TARGET_RTL8763E
#define GPIO_TE_APBPeriph                       APBPeriph_GPIOA
#define GPIO_TE_APBPeriph_CLK                   APBPeriph_GPIOA_CLOCK
#define GPIO_TE_GROUP                           GPIOA
#define GPIO_TE_PIN                             P2_2
#define GPIO_TE_HANDLER                         GPIOA17_Handler
#define GPIO_TE_IRQ                             GPIO17_IRQn
#define GPIO_TE_VECTORn                         GPIOA17_VECTORn
#else
#define GPIO_TE_APBPeriph                       APBPeriph_GPIOB
#define GPIO_TE_APBPeriph_CLK                   APBPeriph_GPIOB_CLOCK
#define GPIO_TE_GROUP                           GPIOB
#define GPIO_TE_PIN                             P4_5
#define GPIO_TE_HANDLER                         GPIOB12_Handler
#define GPIO_TE_IRQ                             GPIO45_IRQn
#define GPIO_TE_VECTORn                         GPIOB12_VECTORn
#endif


void lcd_te_device_init(void)
{
    Pad_Config(GPIO_TE_PIN, PAD_PINMUX_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE,
               PAD_OUT_HIGH);
    Pinmux_Config(GPIO_TE_PIN, DWGPIO);

    RCC_PeriphClockCmd(GPIO_TE_APBPeriph,  GPIO_TE_APBPeriph_CLK,  ENABLE);

    RamVectorTableUpdate(GPIO_TE_VECTORn, GPIO_TE_HANDLER);
    GPIO_InitTypeDef GPIO_Param;
    GPIO_StructInit(&GPIO_Param);
    GPIO_Param.GPIO_PinBit = GPIO_GetPin(GPIO_TE_PIN);
    GPIO_Param.GPIO_Mode = GPIO_Mode_IN;
    GPIO_Param.GPIO_ITCmd = ENABLE;
#if defined TARGET_RTL8763E
    GPIO_Param.GPIO_ITTrigger = GPIO_INT_Trigger_LEVEL;
    GPIO_Param.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
#else
    GPIO_Param.GPIO_ITTrigger = GPIO_INT_Trigger_EDGE;
    GPIO_Param.GPIO_ITPolarity = GPIO_INT_POLARITY_ACTIVE_LOW;
#endif
    GPIOx_Init(GPIO_TE_GROUP, &GPIO_Param);

    GPIOx_INTConfig(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN), DISABLE);
    GPIOx_MaskINTConfig(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN), ENABLE);
    GPIOx_ClearINTPendingBit(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN));

    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = GPIO_TE_IRQ;
    NVIC_InitStruct.NVIC_IRQChannelPriority = 3;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
#if defined TARGET_RTL8763E
    gui_set_te_function(false);
#endif
}

#if defined TARGET_RTL8763E
void lcd_frame_sync_handler(void)
{
    lcd_te_disable();

    T_RTK_GUI_EVENT p_msg;
    p_msg.type = GUI_EVENT_FRAME_SYNC;
    post_event_to_gui_task(&p_msg, __LINE__);
}
#endif
void lcd_te_enable(void)
{
    GPIOx_MaskINTConfig(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN), ENABLE);
    GPIOx_INTConfig(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN), ENABLE);
    GPIOx_ClearINTPendingBit(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN));
    GPIOx_MaskINTConfig(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN), DISABLE);
}

void lcd_te_disable(void)
{
    GPIOx_INTConfig(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN), DISABLE);
    GPIOx_MaskINTConfig(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN), ENABLE);
    GPIOx_ClearINTPendingBit(GPIO_TE_GROUP, GPIO_GetPin(GPIO_TE_PIN));
}

#if defined TARGET_RTL8773E

void lcd_te_enter_dlps(void)
{
    Pad_Config(GPIO_TE_PIN, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_DISABLE, PAD_OUT_LOW);
}

void GPIO_TE_HANDLER(void)
{
    lcd_te_disable();

    rtk_lcd_hal_set_sw_TE_flag(true);
}
#endif
