/**
*****************************************************************************************
*     Copyright(c) 2022, Realtek Semiconductor Corporation. All rights reserved.
*****************************************************************************************
* @file
* @brief
* @author
* @date
* @version
**************************************************************************************
* @attention
* <h2><center>&copy; COPYRIGHT 2022 Realtek Semiconductor Corporation</center></h2>
**************************************************************************************
*/
/* Demo includes. */
#include "rtl876x_gdma.h"
#include "rtl_imdc.h"
#include "rtl876x_rcc.h"
#include "imdc_test_source.h"
#include "trace.h"
#include "string.h"
/*-----------------------------------------------------------*/
static uint8_t __attribute__((aligned(4))) buf[9000];

void IMDC_test(void)
{
    memset(buf, 0xA5, 9000);
    IMDC_file_header *header = (IMDC_file_header *)file_data;

    DBG_DIRECT("algo = %d, blur %d, YUV %d", header->algorithm_type.algorithm,
               header->algorithm_type.feature_2, header->algorithm_type.feature_1);
    DBG_DIRECT("width %d height %d", header->raw_pic_width, header->raw_pic_height);

    IMDC_decode_range range;
    range.start_column = 0;
    range.end_column = header->raw_pic_width - 1;
    range.start_line = 0;
    range.end_line = header->raw_pic_height - 1;
    IMDC_DMA_config dma_cfg;
    dma_cfg.output_buf = (uint32_t *)buf;
    dma_cfg.RX_DMA_channel_num = 0;
    dma_cfg.TX_DMA_channel_num = 1;
    dma_cfg.RX_FIFO_INT_threshold = 8;
    dma_cfg.TX_FIFO_INT_threshold = 8;

    IMDC_Decode(file_data, &range, &dma_cfg);

    for (uint32_t counter = 0; counter < sizeof(decode_file_data); counter++)
    {
        if (buf[counter] == decode_file_data[counter])
        {
            continue;
        }
        else
        {
            DBG_DIRECT("Received_buffer_word[%d] = %x\r\n", counter, buf[counter]);
            DBG_DIRECT("Raw_data_word[%d] = %x\r\n", counter, decode_file_data[counter]);
            DBG_DIRECT("[ERROR] occurs during decompress procedure \r\n");
        }
    }
    DBG_DIRECT("decompress procedure succeeded");
    /*decompress procedure finish*/
}

/*-----------------------------------------------------------*/
